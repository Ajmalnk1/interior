<div class="gpt-main-wrapper">
    <div class="gpt-page-content">
        <div class="gpt-card">
            <div class="gpt-content">
                <h4 class="gpt-form-title"><?php echo esc_html__('Content Generator','gpt-sniper'); ?>
                <a href="<?php echo esc_url('https://kamleshyadav.com/documentation/Codecanyon/gpt-sniper/#contentwriter'); ?>" target="_blank">
                <span class="gpt-has-info">
                    <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svgjs="http://svgjs.com/svgjs" x="0" y="0" viewBox="0 0 23.625 23.625" style="enable-background:new 0 0 512 512" xml:space="preserve"><g><g><path d="M11.812,0C5.289,0,0,5.289,0,11.812s5.289,11.813,11.812,11.813s11.813-5.29,11.813-11.813&#10;&#9;&#9;S18.335,0,11.812,0z M14.271,18.307c-0.608,0.24-1.092,0.422-1.455,0.548c-0.362,0.126-0.783,0.189-1.262,0.189&#10;&#9;&#9;c-0.736,0-1.309-0.18-1.717-0.539s-0.611-0.814-0.611-1.367c0-0.215,0.015-0.435,0.045-0.659c0.031-0.224,0.08-0.476,0.147-0.759&#10;&#9;&#9;l0.761-2.688c0.067-0.258,0.125-0.503,0.171-0.731c0.046-0.23,0.068-0.441,0.068-0.633c0-0.342-0.071-0.582-0.212-0.717&#10;&#9;&#9;c-0.143-0.135-0.412-0.201-0.813-0.201c-0.196,0-0.398,0.029-0.605,0.09c-0.205,0.063-0.383,0.12-0.529,0.176l0.201-0.828&#10;&#9;&#9;c0.498-0.203,0.975-0.377,1.43-0.521c0.455-0.146,0.885-0.218,1.29-0.218c0.731,0,1.295,0.178,1.692,0.53&#10;&#9;&#9;c0.395,0.353,0.594,0.812,0.594,1.376c0,0.117-0.014,0.323-0.041,0.617c-0.027,0.295-0.078,0.564-0.152,0.811l-0.757,2.68&#10;&#9;&#9;c-0.062,0.215-0.117,0.461-0.167,0.736c-0.049,0.275-0.073,0.485-0.073,0.626c0,0.356,0.079,0.599,0.239,0.728&#10;&#9;&#9;c0.158,0.129,0.435,0.194,0.827,0.194c0.185,0,0.392-0.033,0.626-0.097c0.232-0.064,0.4-0.121,0.506-0.17L14.271,18.307z&#10;&#9;&#9; M14.137,7.429c-0.353,0.328-0.778,0.492-1.275,0.492c-0.496,0-0.924-0.164-1.28-0.492c-0.354-0.328-0.533-0.727-0.533-1.193&#10;&#9;&#9;c0-0.465,0.18-0.865,0.533-1.196c0.356-0.332,0.784-0.497,1.28-0.497c0.497,0,0.923,0.165,1.275,0.497&#10;&#9;&#9;c0.353,0.331,0.53,0.731,0.53,1.196C14.667,6.703,14.49,7.101,14.137,7.429z" fill="currentColor" /></g></g></svg>
                <span>
                <?php echo esc_html__('Click here to know more.','gpt-sniper'); ?>
                </span>
                </span>
                <span class="gpt-read-documention"><?php echo esc_html__('Read Documentation','gpt-sniper'); ?></span>
                </a>
                </h4>
                <div class="gpt-from-wrapper"> 
                    <div class="gpt-meta-option-wrapper">
                        <div class="gpt_response_massage"></div>
                        <!-- Post Data  -->
                        <div class="gpt-input-wrapper">
                            <label for="gpt_image_generator_sh">
                            <?php echo esc_html__('Shortcode ( Use this shortcode on your webpage)','gpt-sniper'); ?>
                            </label>
                            <div class="gpt-shortcode">
                            <?php echo esc_html__('[gpt_content_generator_sh]','gpt-sniper'); ?>  
                            </div>  
                            <a href="javascript:void(0);" class="copy-button gpt-btn" id="gpt_copy_text">
                            <?php echo esc_html__('Copy Shortcode','gpt-sniper'); ?></a>
                        </div>
                        <div class="gpt-col-2">
                            <div class="gpt-input-wrapper">
                                <label for="gpt_post_title">
                                <?php echo esc_html__('Title','gpt-sniper'); ?> 
                                </label>
                                <input type="text" name="gpt_post_title" id="gpt_post_title" placeholder="<?php echo esc_attr__('Enter Your Search Content','gpt-sniper'); ?>">
                                <input type="hidden" name="gpt_post_id" id="gpt_post_id" value="<?php echo esc_attr(get_the_ID()); ?>">
                            </div>
                            <div class="gpt-input-wrapper">
                                <label for="gpt_contain_para_number">
                                <?php echo esc_html__('No. of paragraphs','gpt-sniper'); ?> 
                                </label>
                                <select name="gpt_contain_para_number" id="gpt_contain_para_number">
                                    <option value="1" selected=""><?php echo esc_html__('1','gpt-sniper'); ?></option>
                                    <option value="2"><?php echo esc_html__('2','gpt-sniper'); ?></option>
                                    <option value="3"><?php echo esc_html__('3','gpt-sniper'); ?></option>
                                    <option value="4"><?php echo esc_html__('4','gpt-sniper'); ?></option>
                                    <option value="5"><?php echo esc_html__('5','gpt-sniper'); ?></option>
                                    <option value="6"><?php echo esc_html__('6','gpt-sniper'); ?></option>
                                    <option value="7"><?php echo esc_html__('7','gpt-sniper'); ?></option>
                                    <option value="8"><?php echo esc_html__('8','gpt-sniper'); ?></option>
                                    <option value="9"><?php echo esc_html__('9','gpt-sniper'); ?></option>
                                    <option value="10"><?php echo esc_html__('10','gpt-sniper'); ?></option>
                                </select> 
                            </div>
                            <div class="gpt-input-wrapper">
                                <label for="gpt_openai_language">
                                <?php echo esc_html__('Language','gpt-sniper'); ?>
                                </label> 
                                <?php 
                                $gpt_access_oto = get_option('gpt_access_oto');
                                $arr_data = array();
                                if(!empty($gpt_access_oto)):
                                    $arr_data = explode(',', $gpt_access_oto);
                                endif;
                                ?>
                                <select name="gpt_openai_language" id="gpt_openai_language">
                                    <option value="English" selected=""><?php echo esc_html__('English','gpt-sniper'); ?></option>
                                    <option value="Arabic"><?php  echo esc_html__('Arabic','gpt-sniper'); ?></option>
                                    <option value="Bulgarian"><?php  echo esc_html__('Bulgarian','gpt-sniper'); ?></option>
                                    <option value="Chinese"><?php  echo esc_html__('Chinese','gpt-sniper'); ?></option>
                                    <option value="Croatian"><?php  echo esc_html__('Croatian','gpt-sniper'); ?></option>
                                    <option value="Czech"><?php  echo esc_html__('Czech','gpt-sniper'); ?></option>
                                    <option value="Danish"><?php  echo esc_html__('Danish','gpt-sniper'); ?></option>
                                    <option value="Dutch"><?php  echo esc_html__('Dutch','gpt-sniper'); ?></option>
                                    <option value="Filipino"><?php echo esc_html__('Filipino','gpt-sniper'); ?></option>
                                    <option value="Finnish"><?php  echo esc_html__('Finnish','gpt-sniper'); ?></option>
                                    <option value="French"><?php  echo esc_html__('French','gpt-sniper'); ?></option>
                                    <option value="German"><?php  echo esc_html__('German','gpt-sniper'); ?></option>
                                    <option value="Greek"><?php  echo esc_html__('Greek','gpt-sniper'); ?></option>
                                    <option value="Hebrew"><?php  echo esc_html__('Hebrew','gpt-sniper'); ?></option>
                                    <option value="Hindi"><?php  echo esc_html__('Hindi','gpt-sniper'); ?></option>
                                    <option value="Hungarian"><?php  echo esc_html__('Hungarian','gpt-sniper'); ?></option>
                                    <option value="Indonesian"><?php  echo esc_html__('Indonesian','gpt-sniper'); ?></option>
                                    <option value="Italian"><?php  echo esc_html__('Italian','gpt-sniper'); ?></option>
                                    <option value="Japanese"><?php  echo esc_html__('Japanese','gpt-sniper'); ?></option>
                                    <option value="Korean"><?php  echo esc_html__('Korean','gpt-sniper'); ?></option>
                                    <option value="Latvian"><?php  echo esc_html__('Latvian','gpt-sniper'); ?></option>
                                    <option value="Lithuanian"><?php  echo esc_html__('Lithuanian','gpt-sniper'); ?></option>
                                    <option value="Malay"><?php  echo esc_html__('Malay','gpt-sniper'); ?></option>
                                    <option value="Norwegian"><?php  echo esc_html__('Norwegian','gpt-sniper'); ?></option>
                                    <option value="Polish"><?php  echo esc_html__('Polish','gpt-sniper'); ?></option>
                                    <option value="Portuguese"><?php  echo esc_html__('Portuguese','gpt-sniper'); ?></option>
                                    <option value="Romanian"><?php  echo esc_html__('Romanian','gpt-sniper'); ?></option>
                                    <option value="Russian"><?php  echo esc_html__('Russian','gpt-sniper'); ?></option>
                                    <option value="Serbian"><?php  echo esc_html__('Serbian','gpt-sniper'); ?></option>
                                    <option value="Slovak"><?php  echo esc_html__('Slovak','gpt-sniper'); ?></option>
                                    <option value="Slovenian"><?php  echo esc_html__('Slovenian','gpt-sniper'); ?></option>
                                    <option value="panish"><?php  echo esc_html__('panish','gpt-sniper'); ?></option>
                                    <option value="Swedish"><?php  echo esc_html__('Swedish','gpt-sniper'); ?></option>
                                    <option value="Thai"><?php  echo esc_html__('Thai','gpt-sniper'); ?></option>
                                    <option value="Turkish"><?php  echo esc_html__('Turkish','gpt-sniper'); ?></option>
                                    <option value="Ukranian"><?php  echo esc_html__('Ukranian','gpt-sniper'); ?></option>
                                    <option value="Vietnamese"><?php  echo esc_html__('Vietnamese','gpt-sniper'); ?></option>
                                </select>
                            </div>
                        </div>
                        <div class="gpt-col-1">
                            <div class="gpt-input-wrapper">
                                <label for="gpt_add_image">
                                <?php echo esc_html__('Add Image?','gpt-sniper'); ?>
                                </label>
                                <div class="gpt-radio-btn">
                                    <input type="checkbox" class="" id="gpt_add_image">
                                    <label for="gpt_add_image"><span></span></label>
                                </div> 
                            </div>
                            <div class="gpt-input-wrapper" id="gpt-global-image-filed"> 
                                <label for="bpt_openai_image_size">
                                <?php echo esc_html__('Image Size?','gpt-sniper'); ?>
                                </label>
                                <select name="bpt_openai_image_size" id="bpt_openai_image_size">
                                    <option value="256x256"><?php echo esc_html__('Small (256x256)','gpt-sniper'); ?></option>
                                    <option value="512x512" selected=""><?php echo esc_html__('Medium (512x512)','gpt-sniper'); ?></option>
                                    <option value="1024x1024"><?php echo esc_html__('Big (1024x1024)','gpt-sniper'); ?></option>
                                </select> 
                            </div>
                        </div>
                        <div class="gpt-input-wrapper gpt-content-writer">
                            <label for="">
                            <?php echo esc_html__('Content','gpt-sniper'); ?>
                            </label>
                            <textarea name="gpt_post_content" id="gpt_post_content">
                            <?php echo wp_kses(get_post_meta(get_the_ID(),'gpt_post_content',true),true); ?></textarea>
                        </div>
                        <div class="gpt-btn-wrap">
                            <a href="javascript:void(0);" class="gpt-btn" id="gpt_sniper_content_writer">
                            <?php echo esc_html__('Generate','gpt-sniper'); ?></a> 
                        </div>  
                    </div> 
                </div>
            </div> 
        </div> 
    </div> 
</div>
<!-- Loader Section -->
<div class="gpt-preloader">
<img src="<?php echo plugins_url(); ?>/gpt-sniper/admin/images/gpt-loader.svg" alt="<?php echo esc_attr__('loading','gpt-sniper'); ?>">
</div>  