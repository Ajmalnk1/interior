jQuery( document ).ready(function($) {
    'use strict';
    /**
     * WP Media Js
     */
    var data_keys = $(this).parents('.gpt-imported-data').find('.gpt-category option:selected').attr('data-cat');
	if(data_keys == 'Uncategorized'){
		var data_keys = $(this).parents('.gpt-imported-data').find('.post-title').val();
	}
	if(wp.media){
        var image_frame;
        if(image_frame){
            image_frame.open();
            return;
        }
        var l10n = wp.media.view.l10n;
        wp.media.view.MediaFrame.Select.prototype.browseRouter = function (
            routerView
        ) {
            routerView.set({
                upload: {
                    text: l10n.uploadFilesTitle,
                    priority: 20,
                },
                browse: {
                    text: l10n.mediaLibraryTitle,
                    priority: 40,
                },
                my_tab: {
                    text: "GPT Sniper",
                    priority: 60,
                },
            });
        };
        
    /**
	 * Image Buzz Open Modal Reload Page
	 */
    wp.media.view.Modal.prototype.on("open", function () {
        
        if($("body").find(".media-modal-content").last().find(".media-router .media-menu-item.active").text() == "GPT Sniper"){
            setTimeout(function () {
                gptsniper_images_libarys_div();
                $('.gpt-loader').css('display', 'flex');
                $(".gpt-loader").delay(800).fadeOut("slow");
            },1500);  
            var formdata ='data_keys='+data_keys;
            formdata += '&action=gptsniper_wp_media_image_fileload';
            $.ajax({
                type: 'post',
                url: gptsniper_ajax_path.url, 
                data: formdata,
                success: function(response){
                    $(".gpt-loader").delay(800).fadeOut("slow");
                    setTimeout(function () {
                        jQuery(".gpt_media_wrapper").html(response);	
                        $(".gpt-api-buttons a:first-child").addClass('active');
                        $(".gpt-search-image").attr('value',data_keys);
                        $(".gpt_api_buttons").attr('data-keys',data_keys);					 
                    }, 2000); 
                    
                }
            });
            localStorage.setItem('category', data_keys);
        }
         
    });
    
    /**
	 * Image Buzz Media Tab Active
	 */ 
	$(wp.media).on("click", ".media-router .media-menu-item", function (e) {
		$('.gpt-loader').css('display', 'flex');
        if(e.target.innerText == "GPT Sniper") { 
            gptsniper_images_libarys_div();
            var data_keys = localStorage.getItem("category");
            if(data_keys == 'undefined'){
                data_keys = 'Lion';
            }
		    var formdata ='data_keys='+data_keys;
			formdata += '&action=gptsniper_wp_media_image_fileload';
    		$.ajax({
    			type: 'post',
    			url: gptsniper_ajax_path.url, 
    			data: formdata,
    			success: function(response){ 
    				$(".gpt-loader").delay(800).fadeOut("slow");
					setTimeout(function () {
    					jQuery(".gpt_media_wrapper").html(response);	
    					$(".gpt-search-image").attr('value',data_keys);
    				}, 1000);
                } 
    		}); 
		}; 
		
	});
    /**
	 * WP Media In Search Images
	 */
	$(document).on('click','.gpt-image-find-name',function(e) {
		e.preventDefault();	
		$('.gpt-loader').css('display', 'flex');
		var data_keys = $(this).prev().val();
        var data_types = $('.gpt-api-buttons .active').attr('data-types');
		var formdata ='data_types='+data_types+'&data_keys='+data_keys; 
			formdata += '&action=gptsniper_open_search_image'; 
        $.ajax({
			url: gptsniper_ajax_path.url, 
			type: 'POST',
			data : formdata, 
			success: function (response) {
				
				$(".gpt-loader").delay(800).fadeOut("slow");
				
				setTimeout(() => {
					$('.gpt-media-images-ajax').html(response);
				}, 1000);
                
			}
		}); 
		$('.gpt_api_buttons').attr('data-keys',data_keys);
		$('#gpt-images-loadmore').attr('data-keys',data_keys);
		$('#gpt-images-loadmore').attr('data-types',data_types);
		$('#gpt-images-loadmore').attr('data-page',1); 
		localStorage.setItem('category', data_keys);
	});
    
      /**
	 * Images Upload Media
	 */ 
	$(document).on('click','.gpt-savemedia-image', function(event){
		event.preventDefault();	 
        $('.gpt-loader').css('display', 'flex');
        var image = $(this).attr('data-url');
        var title = $(this).attr('data-id'); 
	    var formdata ='image='+image+'&title='+title; 
			formdata += '&action=gptsniper_upload_save_media'; 
		$.ajax({
			url: gptsniper_ajax_path.url, 
			type: 'POST',
			data : formdata, 
			success: function (response) { 
                $(".gpt-loader").delay(800).fadeOut("slow");
                var result = JSON.parse(response);						
                if(result.status == 'true'){
					var test = $("body").find(".media-modal-content").last().find(".media-router .media-menu-item.active").prev().click();
                    wp.media.frame.setState("insert");
                    if (wp.media.frame.content.get() !== null) {
                        wp.media.frame.content
                            .get()
                            .collection.props.set({ ignore: +new Date() });
                        let f = wp.media.frame.content.get().collection.select()[0];
                        wp.media.frame.content.get().options.selection.reset(f);
						toastr.success("Images has been saved in media library"); 
                    } else {
						toastr.warning("Images has been saved in media library, if you are not able to see them please reload media or do the hard refresh.");
						
						if(wp.media){  
							wp.media.frame.content.view._selection.attachments.props.set({ ignore: +new Date() });  
                        } 
                    } 
                    
                    setTimeout(() => {
                        let sm = $(
                            ".media-frame-content .attachments-browser .attachments-wrapper ul"
                        )[0];
                        sm.children[0].click();
                       
                    }, 1000);
                } else {
                    toastr["error"](result.msg);
				}
			}
		});
	}); 
  
    /**
     * Gpt Sniper Image Loading Div 
     */
    const gptsniper_images_libarys_div = () =>{
         var html ='<div class="gpt_media_wrapper"></div><div class="gpt-loader"><div class="gpt-loader-inner"><svg xmlns:svg="http://www.w3.org/2000/svg" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.0" width="80px" height="80px" viewBox="0 0 128 128" xml:space="preserve"><rect x="0" y="0" width="100%" height="100%" fill="#FFFFFF" /><g><path d="M54 28.75A114.97 114.97 0 0 0 60 15a118.9 118.9 0 0 0 4-15 119.06 119.06 0 0 0 4 15 114.76 114.76 0 0 0 6 13.75 47.17 47.17 0 0 0-10-1.25 47.43 47.43 0 0 0-10 1.25zM81.82 32a114.97 114.97 0 0 0 13.97-5.5 118.8 118.8 0 0 0 13.42-7.77 119.1 119.1 0 0 0-7.78 13.44 114.78 114.78 0 0 0-5.48 13.96 47.17 47.17 0 0 0-6.2-7.95 47.42 47.42 0 0 0-7.94-6.2zm17.43 22A115 115 0 0 0 113 60a118.9 118.9 0 0 0 15 4 119.07 119.07 0 0 0-15 4 114.77 114.77 0 0 0-13.75 6 47.17 47.17 0 0 0 1.25-10 47.43 47.43 0 0 0-1.25-10zm-3.28 27.78a115 115 0 0 0 5.48 13.97 118.93 118.93 0 0 0 7.77 13.43 118.94 118.94 0 0 0-13.43-7.77 114.72 114.72 0 0 0-13.98-5.47 47.17 47.17 0 0 0 7.95-6.18 47.43 47.43 0 0 0 6.2-7.96zM74 99.25A115 115 0 0 0 68 113a118.9 118.9 0 0 0-4 15 119.07 119.07 0 0 0-4-15 114.77 114.77 0 0 0-6-13.75 47.17 47.17 0 0 0 10 1.25 47.43 47.43 0 0 0 10-1.25zm-27.83-3.33a114.94 114.94 0 0 0-13.96 5.5 118.74 118.74 0 0 0-13.42 7.76 119.05 119.05 0 0 0 7.78-13.43 114.77 114.77 0 0 0 5.48-13.97 47.17 47.17 0 0 0 6.2 7.96 47.43 47.43 0 0 0 7.95 6.2zM28.75 74A114.97 114.97 0 0 0 15 68a118.9 118.9 0 0 0-15-4 119.06 119.06 0 0 0 15-4 114.76 114.76 0 0 0 13.75-6 47.17 47.17 0 0 0-1.25 10 47.43 47.43 0 0 0 1.25 10zm3.28-27.87a114.97 114.97 0 0 0-5.48-13.96 118.9 118.9 0 0 0-7.77-13.44A119.06 119.06 0 0 0 32.2 26.5 114.76 114.76 0 0 0 46.18 32a47.17 47.17 0 0 0-7.95 6.18 47.43 47.43 0 0 0-6.2 7.95z" fill="#086add"/><animateTransform attributeName="transform" type="rotate" from="0 64 64" to="45 64 64" dur="810ms" repeatCount="indefinite"></animateTransform></g></svg></div></div>';  
        jQuery("body .supports-drag-drop .media-frame-content").html(html);    
        
	 }   
   }
     
   /**
    * Gpt Sniper Images Generator 
    */
    $(document).on('click','#gpt_image_generate',function(e) {
        e.preventDefault();	
        $('.gpt-preloader').css('display', 'flex');
        var data_keys = $('#gpt_image_uset_input_text').val();
        var image_artist = $('#gpt_image_artist').val();
        var image_style = $('#gpt_image_style').val();
        var image_photography = $('#gpt_image_photography').val();
        var image_lighting = $('#gpt_image_lighting').val();
        var image_subject = $('#gpt_image_subject').val();
        var image_Camera = $('#gpt_image_Camera').val();
        var image_composition = $('#gpt_image_composition').val();
        var images_resolution = $('#gpt_images_resolution').val();
        var image_color = $('#gpt_image_color').val();
        var image_effects = $('#gpt_image_effects').val();
        var image_size = $('#gpt_image_size').val();
        var image_number_of = $('#gpt_image_number_of').val();
        var formdata ='data_keys='+data_keys+'&image_artist='+image_artist+'&image_style='+image_style+'&image_photography='+image_photography+'&image_lighting='+image_lighting+'&image_subject='+image_subject+'&image_Camera='+image_Camera+'&image_composition='+image_composition+'&images_resolution='+images_resolution+'&image_color='+image_color+'&image_effects='+image_effects+'&image_size='+image_size+'&image_number_of='+image_number_of;  
        formdata += '&action=gptsniper_openai_img_generator'; 
        $.ajax({
            url: gptsniper_ajax_path.url, 
            type: 'POST',
            data : formdata, 
            success: function (response) {
             $(".gpt-preloader").delay(800).fadeOut("slow");
             $(".gpt-preloader").delay(500).fadeOut("slow");
             $('.gpt-image-results').html(response);
            }  
        }); 
    });
    /**
     * Download Image File
     */
    $(document).on('click',".gpt_download_image",function (e) {
        e.preventDefault();
        let name = 'openapi';
        let image_url = $(this).attr('data-url');
        var link = document.createElement("a");
        link.setAttribute('download', name);
        link.href = image_url;
        document.body.appendChild(link);
        link.click();
        link.remove();
    }); 

    /**
     * Gpt Sniper General Api Setting JS
     */
    $(document).on('click','#gpt_api_save_data',function(e) {
        e.preventDefault();	
        $('.gpt-preloader').css('display', 'flex');
        let api_key = $('#gpt_open_api_key').val();
        let model_option = $('#gpt_model_option').val();
        let temperature = $('#gpt_temperature').val();
        let max_tokens = $('#max_tokens').val();
        let top_p = $('#gpt_top_p').val();
        let best_of = $('#gpt_best_of').val();
        let frequency_penalty = $('#gpt_frequency_penalty').val();
        let presence_penalty = $('#gpt_presence_penalty').val();
        var post_list_data = [];
        $('.gpt_post_types:checked').each(function() {
            post_list_data.push($(this).val());
        });
        var formdata ='api_key='+api_key+'&model_option='+model_option+'&temperature='+temperature+'&max_tokens='+max_tokens+'&top_p='+top_p+'&best_of='+best_of+'&frequency_penalty='+frequency_penalty+'&presence_penalty='+presence_penalty+'&post_list_data='+post_list_data; 
        formdata += '&action=gptsniper_general_api_settings'; 
        $.ajax({
            url: gptsniper_ajax_path.url, 
            type: 'POST',
            data : formdata,  
            success: function (response) {
             let res_data = JSON.parse(response); 
             if(res_data.status==true){
                toastr.success(res_data.message); 
                $('.gpt_response_massage').html('<span style="color:green;">'+res_data.message+'</span>');
             }else{
                toastr.warning(res_data.message);
                $('.gpt_response_massage').html('<span style="color:red;">'+res_data.message+'</span>');
             }
             $(".gpt-preloader").delay(800).fadeOut("slow");
             $(".gpt-preloader").delay(500).fadeOut("slow");
             setTimeout(function(){
                $('.gpt_response_massage').hide();
             }, 5000);
            } 
        }); 
    });

    /**
     * Gpt Sniper Content Generator 
     */
    $(document).on('click','#gpt_post_page_content_generate',function(e){
        e.preventDefault();
          
        let title = $('#gpt_post_title').val();
        let post_id = $('#gpt_post_id').val();
        let add_image = $('#gpt_add_image').is(':checked'); 
        let feature_image = $('#gpt_feature_image').is(':checked');  
        let feature_image_size = $('#bpt_openai_image_size').val();  
        let openai_language = $('#gpt_openai_language').val(); 
        let number_of_paragraphs = $('#gpt_contain_para_number').val(); 
        if(title == ''){
            toastr.error('Please Enter Search Text');
            return false;
        }else{ 
            $('.gpt-preloader').css('display', 'flex');
            var formdata ='title='+title+'&post_id='+post_id+'&add_image='+add_image+'&feature_image='+feature_image+'&feature_image_size='+feature_image_size+'&openai_language='+openai_language+'&number_of_paragraphs='+number_of_paragraphs;   
            formdata += '&action=gptsniper_content_generator';
           
            $.ajax({
                url: gptsniper_ajax_path.url, 
                type: 'POST',
                data : formdata,  
                success: function (response) {
                    
                    let res_data = JSON.parse(response); 
                    $(".gpt-preloader").delay(800).fadeOut("slow");
                    $(".gpt-preloader").delay(500).fadeOut("slow");
                    
                    
                    if(res_data.status==200){
                       
                        toastr.success(res_data.message); 
                        $('.gpt_response_massage').html('<span style="color:green;">'+res_data.message+'</span>');  
                        localStorage.setItem('search_post_content',res_data.content_data);
                        setTimeout(function(){
                        window.location.replace(res_data.post_url);
                        }, 500); 
                    }else{  
                         
                        if(res_data.status==429){
                          
                         }else{
                           toastr.error(res_data.message);
                           $('.gpt_response_massage').html('<span style="color:green;">'+res_data.message+'</span>');
                         }
                        
                    }
                } 
            }); 
       }
    }); 
   /**
    * Gpt Sniper Content Writer
    */
    $(document).on('click','#gpt_sniper_content_writer',function(e){
        e.preventDefault();
        
        let title = $('#gpt_post_title').val();
        let post_id = $('#gpt_post_id').val();
        let add_image = $('#gpt_add_image').is(':checked'); 
        let feature_image = $('#gpt_feature_image').is(':checked');  
        let feature_image_size = $('#bpt_openai_image_size').val();  
        let openai_language = $('#gpt_openai_language').val(); 
        let number_of_paragraphs = $('#gpt_contain_para_number').val();  
        if(title == ''){
            toastr.error('Please Enter Search Text');
            return false;
        }else{ 
            $('.gpt-preloader').css('display', 'flex');
            var formdata ='title='+title+'&post_id='+post_id+'&add_image='+add_image+'&feature_image='+feature_image+'&feature_image_size='+feature_image_size+'&openai_language='+openai_language+'&number_of_paragraphs='+number_of_paragraphs;   
            formdata += '&action=gptsniper_content_generator'; 
            $.ajax({
                url: gptsniper_ajax_path.url, 
                type: 'POST',
                data : formdata,  
                success: function (response) {
                    let res_data = JSON.parse(response); 
                    $(".gpt-preloader").delay(800).fadeOut("slow");
                    $(".gpt-preloader").delay(500).fadeOut("slow"); 
                    if(res_data.status==200){
                        $('.gpt-content-writer').show(); 
                        toastr.success(res_data.message); 
                        $('#gpt_post_content').html(res_data.content_data);
                        $('.gpt_response_massage').html('<span style="color:green;">'+res_data.message+'</span>');  
                    }else{  
                        toastr.error(res_data.message);
                        $('.gpt_response_massage').html('<span style="color:green;">'+res_data.message+'</span>');
                    }
                } 
            }); 
       }
    }); 
    /**
     * Gpt Sniper Seo Content Js
     */
    $(document).on('click','#gpt_sniper_seo_content',function(e) {
        e.preventDefault();	
        let keywords = $('#search_key_words').val();
        if(keywords == ''){
            toastr.error('Please Enter Search KeyWords');
            return false;
        }else{ 
            $('.gpt-preloader').css('display', 'flex');
            var formdata ='keywords='+keywords; 
            formdata += '&action=gptsniper_seo_content'; 
            $.ajax({
                url: gptsniper_ajax_path.url, 
                type: 'POST',
                data : formdata,  
                success: function (response) {
                    $(".gpt-preloader").delay(800).fadeOut("slow");
                    $(".gpt-preloader").delay(500).fadeOut("slow"); 
                    let res_data = JSON.parse(response); 
                    if(res_data.status==200){
                        $('.gpt_seo_showhide').show();
                        toastr.success(res_data.message); 
                        let output = res_data.content_data;
                        const pageTitle = output.match(/Page title:\s*(.*)/, 1)[1];
                        const metaDescription = output.match(/Meta description:\s*(.*)/, 1)[1];
                        $('#gpt_page_title').val(pageTitle); 
                        $('#gpt_sec_gconent').text(metaDescription);
                    }else{  
                         
                        if(res_data.status==429){
                         }else{
                           toastr.error(res_data.message);
                           $('.gpt_response_massage').html('<span style="color:green;">'+res_data.message+'</span>');
                         }
                        
                    }
                } 
            }); 
        
        } 
    }); 
    /**
     * gpt sniper content checkbox
     */  
    $("#gpt_add_image").on('change',function() {
        var ischecked= $(this).is(':checked');
        if(!ischecked){
           $('#gpt-global-image-filed').hide();
        }else{
           $('#gpt-global-image-filed').show();
        } 
    });  
    /**
     * Gpt Seo Content Save
     */
    $(document).on('change','#seo-html',function(e) {
        e.preventDefault();	
        let includ_text_check = $(this).is(':checked'); 
        let page_title = $('#gpt_page_title').val();
        let meta_description = $('#gpt_sec_gconent').val();
        $('.gpt-preloader').css('display', 'flex');
            var formdata ='page_title='+page_title+'&meta_description='+meta_description+'&includ_text_check='+includ_text_check; 
            formdata += '&action=gptsniper_seo_content_save'; 
            $.ajax({
                url: gptsniper_ajax_path.url, 
                type: 'POST',
                data : formdata,  
                success: function (response) {
                    $(".gpt-preloader").delay(800).fadeOut("slow");
                    $(".gpt-preloader").delay(500).fadeOut("slow"); 
                    let res_data = JSON.parse(response); 
                    if(res_data.status==200){
                        
                    }else{  
                        toastr.error(res_data.message);
                        $('.gpt_response_massage').html('<span style="color:green;">'+res_data.message+'</span>');
                    }
                } 
            }); 
    });

    /**
     * Gpt Sniper Quetion & Answers 
     */
    $(document).on('click','#gpt_quetion_answers_generate',function(e) {
        e.preventDefault();
        let quetion_description = $('#gpt_quetion_text').val();  
        if(quetion_description == ''){
            toastr.error('Please Enter Search KeyWords');
            return false;
        }else{ 
            $('.gpt-preloader').css('display', 'flex'); 
            var formdata ='quetion_description='+quetion_description;
            formdata += '&action=gptsniper_quetion_anwsers'; 
            $.ajax({
                url: gptsniper_ajax_path.url, 
                type: 'POST',
                data : formdata,  
                success: function (response) { 
                    let res_data = JSON.parse(response); 
                    if(res_data.status==200){
                        $('#gpt_quetion_text').val("");  
                        toastr.success(res_data.message); 
                        var quetion = "<p class='gpt-quetion'>Q. "+quetion_description+"</p>";
                        var answers = "<p class='gpt-anwsers'><span>A.</span> "+res_data.content_data+"</p>";
                        var quandans = "<div class='gpt-faq'>"+quetion+answers+"</div>"; 
                        $('#gpt_questions_and_answers').before(quandans); 
                    }else{  
                        if(res_data.status==429){
                         }else{
                           toastr.error(res_data.message);
                           $('.gpt_response_massage').html('<span style="color:green;">'+res_data.message+'</span>');
                         }

                    }
                    $(".gpt-preloader").delay(800).fadeOut("slow");
                    $(".gpt-preloader").delay(500).fadeOut("slow"); 
                }  
            });  
        }   
    });

    /**
     * Gpt Sniper Chat Mode
     */
    $('.gpt-typing-balls').hide();
    $(document).on('click','#gpt_chat_option_send',function(e) {
        e.preventDefault();
        let chat_get_value = $('#gpt_chat_option_input').val();  
        if(chat_get_value == ''){
            toastr.error('Please Type Here!');
            return false;
        }else{ 
            $('.gpt-typing-balls').show(); 
            var formdata ='chat_get_value='+chat_get_value;
            formdata += '&action=gptsniper_chatbot_option_ajax';  
            $.ajax({
                url: gptsniper_ajax_path.url, 
                type: 'POST',
                data : formdata,  
                success: function (response) { 
                    $('#gpt_chat_option_input').val('');
                    $('.gpt-typing-balls').hide();
                    let res_data = JSON.parse(response); 
                    if(res_data.status==200){
                        let output = '<div class="gpt_chat_output"><span><small>AI</small>'+res_data.content_data+'</span></div>'; 
                        let input = '<div class="gpt_chat_input"><span><small>You</small>'+chat_get_value+'</span></div>';
                        let response = input+output; 
                        $('.gpt-chatbox-messages').before(response);
                    }else{   

                        if(res_data.status==429){
                        }else{
                           toastr.error(res_data.message);
                           $('.gpt_response_massage').html('<span style="color:green;">'+res_data.message+'</span>');
                        }   
                    }
                    $(".gpt-preloader").delay(800).fadeOut("slow");
                    $(".gpt-preloader").delay(500).fadeOut("slow"); 
                }  
            }); 
        }
    });
    /**
	 *Gpt Sniper Enter Button Event
	 */
	$(document).on('keypress','#gpt_chat_option_input',function(e) {
		var key = e.which;
		if (key == 13) {
			let chat_get_value = $('#gpt_chat_option_input').val();  
			if(chat_get_value == ''){
				toastr.error('Please Type Here!');
				return false;
			}else{ 
				$('.gpt-typing-balls').show(); 
				var formdata ='chat_get_value='+chat_get_value;
				formdata += '&action=gptsniper_chatbot_option_ajax';  
				$.ajax({
					url: gptsniper_ajax_path.url, 
					type: 'POST',
					data : formdata,  
					success: function (response) { 
						$('#gpt_chat_option_input').val('');
                        $('.gpt-typing-balls').hide();
                        let res_data = JSON.parse(response); 
	                    if(res_data.status==200){
							let output = '<div class="gpt_chat_output"><span><small>AI</small>'+res_data.content_data+'</span></div>'; 
							let input = '<div class="gpt_chat_input"><span><small>You</small>'+chat_get_value+'</span></div>';
							let response = input+output; 
							$('.gpt-chatbox-messages').before(response);
						}else{  
                            if(res_data.status==429){
                            }else{
							  toastr.error(res_data.message);
							  $('.gpt_response_massage').html('<span style="color:green;">'+res_data.message+'</span>');
                            }
                        }
						$(".gpt-preloader").delay(800).fadeOut("slow");
						$(".gpt-preloader").delay(500).fadeOut("slow"); 
					}  
				}); 
			}
	    }
	  });  
    /**
     * Gpt Sniper Chatbot Copy Text Function
     */
    $(document).on('click','#gpt_copy_text',function(e) {
        toastr.success("Copy Shortcode");
        var $temp = $("<input>");
        $("body").append($temp);
        $temp.val($('.gpt-shortcode').text()).select();
        document.execCommand("copy");
        $temp.remove();
        
    });
    /**
     * Gpt Sniper Chatbot Font Side Setting Option
     */
    $(document).on('click','#gpt_chatbot_setting',function(e){
      e.preventDefault();
        let chatbot_position = $('#gpt_chatbot_position').val();  
        let chatbot_font_size = $('#gpt_chatbot_font_size').val();  
        let font_color = $('#font_color').val(); 
        let label_font_color = $('#label_font_color').val(); 
        let bg_color = $('#bg_color').val();    
		let chatbot_title_bg_color = $('#chatbot_title_bg_color').val();  
		let chatbot_title_font_color = $('#chatbot_title_font_color').val();  
        $('.gpt-preloader').css('display', 'flex'); 
        var formdata ='chatbot_position='+chatbot_position+'&chatbot_font_size='+chatbot_font_size+'&font_color='+font_color+'&bg_color='+bg_color+'&label_font_color='+label_font_color+'&chatbot_title_font_color='+chatbot_title_font_color+'&chatbot_title_bg_color='+chatbot_title_bg_color;
        formdata += '&action=gptsniper_chatbot_custom_setting'; 
        $.ajax({
            url: gptsniper_ajax_path.url, 
            type: 'POST',
            data : formdata,  
            success: function (response) { 
                $('#gpt_chat_option_input').val('');
                let res_data = JSON.parse(response); 

                $('.gpt-typing-balls').hide();
                if(res_data.status==true){
                    toastr.success(res_data.message); 
                    location.reload();
                }else{   
                    toastr.error(res_data.message);
                }
                $(".gpt-preloader").delay(800).fadeOut("slow");
                $(".gpt-preloader").delay(500).fadeOut("slow"); 
            }  
         }); 
    })
    /**
     * Gpt Sniper Chatbot Q&s Setting
     */
    $(document).on('click','#gpt_qa_setting',function(e){
          e.preventDefault();
          let qa_font_size = $('#gpt_qa_font_size').val();  
          let font_color = $('#font_color').val(); 
          let label_font_color = $('#label_font_color').val(); 
          let bg_color = $('#bg_color').val();   
          $('.gpt-preloader').css('display', 'flex'); 
          var formdata ='&qa_font_size='+qa_font_size+'&font_color='+font_color+'&bg_color='+bg_color+'&label_font_color='+label_font_color;
          formdata += '&action=gptsniper_qa_custom_setting';  
          $.ajax({ 
              url: gptsniper_ajax_path.url, 
              type: 'POST',
              data : formdata,  
              success: function (response) { 
                    let res_data = JSON.parse(response); 
                    if(res_data.status==true){
                        toastr.success(res_data.message); 
                        location.reload();
                    }else{   
                        toastr.error(res_data.message);
                    }
                  $(".gpt-preloader").delay(800).fadeOut("slow");
                  $(".gpt-preloader").delay(500).fadeOut("slow"); 
              }  
           }); 
    })
    /**
     * GPT Sniper Schedule Poster
     */
    $(document).on('change','#gpt_add_featured_image',function(e){
        let add_featured_image = $('#gpt_add_featured_image:checked').val();  
        if(add_featured_image==='true'){
            $('#gpt_openai_image_size_data').show();
        }else{
            $('#gpt_openai_image_size_data').hide();  
        }
    });
    $(document).on('change','#gpt_add_image',function(e){
        let gpt_add_image = $('#gpt_add_image:checked').val();  
        if(gpt_add_image==='true'){
            $('#gpt_openai_image_size_data').show();
        }else{
            $('#gpt_openai_image_size_data').hide();  
        }
    }); 
    
    $(document).on('click','#gpt_sniper_schedule_save',function(e){
        e.preventDefault();
        let gpt_scheduler_name = $('#gpt_scheduler_name').val(); 
        let scheduler_keywords = $('#gpt_scheduler_keywords').val();  
        let post_crontime = $('#gpt_post_crontime').val(); 
        let gpt_post_status = $('#gpt_post_status').val(); 
        let add_featured_image = $('#gpt_add_featured_image:checked').val();  
        if(add_featured_image==='true'){
            $('#gpt_openai_image_size_data').show();
        } 
        let gpt_add_image = $('#gpt_add_image:checked').val(); 
        let gpt_openai_image_size = $('#gpt_openai_image_size').val(); 
        $('.gpt-preloader').css('display', 'flex'); 
        var formdata ='gpt_scheduler_name='+gpt_scheduler_name+'&scheduler_keywords='+scheduler_keywords+'&post_crontime='+post_crontime+'&gpt_post_status='+gpt_post_status+'&add_featured_image='+add_featured_image+'&gpt_add_image='+gpt_add_image+'&gpt_openai_image_size='+gpt_openai_image_size;
        formdata += '&action=gptsniper_add_schedule_post'; 
        $.ajax({
            url: gptsniper_ajax_path.url, 
            type: 'POST',
            data : formdata,  
            success: function (response) { 
                let res_data = JSON.parse(response); 
                if(res_data.status==true){
                    toastr.success(res_data.message); 
                    location.reload();
                }else{   
                    toastr.error(res_data.message);
                } 
                $(".gpt-preloader").delay(800).fadeOut("slow");
                $(".gpt-preloader").delay(500).fadeOut("slow"); 
            }  
        }); 

    });

    /**
     * GPT Sniper Schedule Detele
     */
    $(document).on('click','.pas-delete-btn',function(e){
        e.preventDefault(); 
        let row_id = $(this).attr('data-rowid');  
        var result = confirm("Want to delete?");
        if (result) {
            $('.gpt-preloader').css('display', 'flex'); 
            var formdata ='row_id='+row_id;
            formdata += '&action=gptsniper_delete_Schedule'; 
            $.ajax({ 
                url: gptsniper_ajax_path.url, 
                type: 'POST',
                data : formdata,  
                success: function (response) { 
                    let res_data = JSON.parse(response); 
                    if(res_data.status==true){
                        toastr.success(res_data.message); 
                        location.reload();
                    }else{   
                        toastr.error(res_data.message);
                    } 
                    $(".gpt-preloader").delay(800).fadeOut("slow");
                    $(".gpt-preloader").delay(500).fadeOut("slow"); 
                }  
            }); 
        }

    });
    /**
     * Auto post schedule
     */
    $(document).ready(function() {
        $('[open-modal]').on('click', function(){
            $('body').addClass("modal-open");
            var id = $(this).attr('open-modal');
            $('.custom-modal#'+id).addClass('active');
        });
        $('[close-modal]').on('click', function(){
            $('body').removeClass("modal-open");
            $(this).parents('.custom-modal').removeClass('active');
        });
        $('.custom-modal').on('click', function(e) {
            if(e.target !== this){return};
            $(this).removeClass('active');
            $('body').removeClass("modal-open");
        });
    });
}); 