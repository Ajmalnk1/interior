<?php 
$chatbot_custom_setting = json_decode(get_option('gpt_chatbot_custom_setting'),true);
$qa_custom_setting = json_decode(get_option('gpt_qa_custom_setting'),true);
?>
<style type="text/css">
.gpt-chatbot-content .gpt_chat_msg > span{
        background-color: <?php if(!empty($chatbot_custom_setting['chatbot_bg_color'])): echo esc_attr($chatbot_custom_setting['chatbot_bg_color']); endif; ?>;
        font-size: <?php if(!empty($chatbot_custom_setting['chatbot_font_size'])): echo esc_attr($chatbot_custom_setting['chatbot_font_size']); endif; ?>;
        color: <?php if(!empty($chatbot_custom_setting['chatbot_font_color'])): echo esc_attr($chatbot_custom_setting['chatbot_font_color']); endif; ?>
    }
    .gpt-chatbox-messages .gpt_chat_msg > span{
        background-color: <?php if(!empty($chatbot_custom_setting['chatbot_bg_color'])): echo esc_attr($chatbot_custom_setting['chatbot_bg_color']); endif; ?>;
        font-size: <?php if(!empty($chatbot_custom_setting['chatbot_font_size'])): echo esc_attr($chatbot_custom_setting['chatbot_font_size']); endif; ?>;
        color: <?php if(!empty($chatbot_custom_setting['chatbot_font_color'])): echo esc_attr($chatbot_custom_setting['chatbot_font_color']); endif; ?>
    }
    .gpt-chatbot-content .gpt_chat_msg > span small,
    .gpt-chatbox-messages .gpt_chat_msg > span small {
        font-size: <?php if(!empty($chatbot_custom_setting['chatbot_font_size'])): echo esc_attr($chatbot_custom_setting['chatbot_font_size']); endif; ?>;
        color: <?php if(!empty($chatbot_custom_setting['label_font_color'])): echo esc_attr($chatbot_custom_setting['label_font_color']); endif; ?> 
    }
	
	.gpt-chatbot-wrap.gpt-chatbot-right.gpt-chat-has-title .gpt-form-title, .gpt-chatbot-wrap.gpt-chatbot-left.gpt-chat-has-title .gpt-form-title {
		background-color: <?php if(!empty($chatbot_custom_setting['chatbot_title_bg_color'])): echo esc_attr($chatbot_custom_setting['chatbot_title_bg_color']); endif; ?>;
        color: <?php if(!empty($chatbot_custom_setting['chatbot_title_font_color'])): echo esc_attr($chatbot_custom_setting['chatbot_title_font_color']); endif; ?>
	}
	/* FAQ css*/
	.gpt-faq-container .gpt-inputwith-btn .gpt-btn {
		background: <?php if(!empty($qa_custom_setting['qa_bg_color'])): echo esc_attr($qa_custom_setting['qa_bg_color']); endif; ?>;
	}
	.gpt-faq-title{
		
		font-size: <?php if(!empty($qa_custom_setting['qa_font_size'])): echo esc_attr($qa_custom_setting['qa_font_size']); endif; ?>;
		color: <?php if(!empty($qa_custom_setting['qa_font_color'])): echo esc_attr($qa_custom_setting['qa_font_color']); endif; ?>
	}
	.gpt-faq-container .gpt-inputwith-btn input:focus {
	  border-color: <?php if(!empty($qa_custom_setting['qa_bg_color'])): echo esc_attr($qa_custom_setting['qa_bg_color']); endif; ?>;
	}
	
	/* End FAQ css*/
</style>