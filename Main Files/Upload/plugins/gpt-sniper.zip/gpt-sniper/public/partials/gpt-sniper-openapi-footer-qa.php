<div class="gpt-faq-wrapper gpt-footer-widget">
	<div class="gpt-faq-content">
		<div class="gpt-faq-container">
			<div class="gpt-input-wrapper">
				 <?php echo esc_html__('What is your Question Today ?','gpt-sniper'); ?>
			    <div class="gpt-inputwith-btn">
					<input type="text" name="gpt_quetion_text" id="gpt_quetion_text" placeholder="<?php echo esc_attr__('Please Enter Your Questions','gpt-sniper'); ?>" />
					<a href="javascript:void(0);" class="gpt-faq-btn gpt-btn" id="gpt_quetion_answers_generate">
						<?php echo esc_html__('Get Answer','gpt-sniper'); ?>
					</a>
				</div>
			</div>
		   <div class="gpt-input-wrapper" id="gpt_questions_and_answers"></div> 
		</div>
	</div>
</div> 
<!-- Loader Section -->
<div class="gpt-preloader">
  <img src="<?php echo plugins_url(); ?>/gpt-sniper/admin/images/gpt-loader.svg" alt="<?php echo esc_attr__('loading','gpt-sniper'); ?>">
</div> 