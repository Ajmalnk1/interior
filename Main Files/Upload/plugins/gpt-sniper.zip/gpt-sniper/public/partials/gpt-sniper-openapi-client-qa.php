<div class="gpt-faq-wrapper">
	<div class="gpt-faq-content">
		<h4 class="gpt-faq-title">
		<?php
		if(!empty($atts['title'])):
		    echo esc_html($atts['title']);
		else: 
			esc_html__('Do you have any question ?','gpt-sniper');
		endif;
		$qa_custom_setting = json_decode(get_option('gpt_qa_custom_setting'),true);
		?>
		</h4> 
		<div class="gpt-faq-container">
			<div class="gpt-input-wrapper">
			    <label for="gpt_quetion_text">
				 <?php echo esc_html__('What is your Question Today ?','gpt-sniper'); ?>
				</label>
			    <div class="gpt-inputwith-btn">
					<input type="text" name="gpt_quetion_text" id="gpt_quetion_text" placeholder="<?php echo esc_attr__('Please Enter Your Questions','gpt-sniper'); ?>" />
					<a href="javascript:void(0);" class="gpt-faq-btn gpt-btn" id="gpt_quetion_answers_generate">
						<?php echo esc_html__('Get Answer','gpt-sniper'); ?>
					</a>
				</div>
			</div>
		   <div class="gpt-input-wrapper" id="gpt_questions_and_answers"></div> 
		</div>
	</div>
	<!-- Loader Section -->
    <div class="gpt-preloader" id="gpt-faqss">
      <img src="<?php echo plugins_url(); ?>/gpt-sniper/admin/images/gpt-loader.svg" alt="<?php echo esc_attr__('loading','gpt-sniper'); ?>">
    </div> 
</div> 