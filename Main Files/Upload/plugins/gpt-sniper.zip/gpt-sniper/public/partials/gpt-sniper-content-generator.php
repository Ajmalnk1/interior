<div class="gpt-shortcode gpt-content-generator">
    <div class="gpt-card">
        <div class="gpt-from-wrapper"> 
            <div class="gpt-meta-option-wrapper">
                <div class="gpt_response_massage"></div>
                <div class="gpt-input-wrapper">
                    <label for="gpt_post_title">
                    <?php echo esc_html__('Title','gpt-sniper'); ?> 
                    </label>
                    <input type="text" name="gpt_post_title" id="gpt_post_title" placeholder="<?php echo esc_attr__('Enter Your Search Content','gpt-sniper'); ?>">
                    <input type="hidden" name="gpt_post_id" id="gpt_post_id" value="<?php echo esc_attr(get_the_ID()); ?>">
                </div>
                <div class="gpt-input-wrapper">
                    <label for="gpt_contain_para_number">
                    <?php echo esc_html__('No. of paragraphs','gpt-sniper'); ?> 
                    </label>
                    <select name="gpt_contain_para_number" id="gpt_contain_para_number">
                        <option value="1" selected=""><?php echo esc_html__('1','gpt-sniper'); ?></option>
                        <option value="2"><?php echo esc_html__('2','gpt-sniper'); ?></option>
                        <option value="3"><?php echo esc_html__('3','gpt-sniper'); ?></option>
                        <option value="4"><?php echo esc_html__('4','gpt-sniper'); ?></option>
                        <option value="5"><?php echo esc_html__('5','gpt-sniper'); ?></option>
                        <option value="6"><?php echo esc_html__('6','gpt-sniper'); ?></option>
                        <option value="7"><?php echo esc_html__('7','gpt-sniper'); ?></option>
                        <option value="8"><?php echo esc_html__('8','gpt-sniper'); ?></option>
                        <option value="9"><?php echo esc_html__('9','gpt-sniper'); ?></option>
                        <option value="10"><?php echo esc_html__('10','gpt-sniper'); ?></option>
                    </select> 
                </div>
                <!-- Post Data  -->
                <div class="gpt-col-2">
                    <div class="gpt-input-wrapper">
                        <label for="gpt_openai_language">
                            <?php echo esc_html__('Language','gpt-sniper'); ?>
                        </label> 
                        <?php 
                        $gpt_access_oto = get_option('gpt_access_oto');
                        $arr_data = array();
                        if(!empty($gpt_access_oto)):
                            $arr_data = explode(',', $gpt_access_oto);
                        endif;
                        ?>
                        <select name="gpt_openai_language" id="gpt_openai_language">
                            <option value="English" selected=""><?php echo esc_html__('English','gpt-sniper'); ?></option>
                            <option value="Arabic"><?php  echo esc_html__('Arabic','gpt-sniper'); ?></option>
                            <option value="Bulgarian"><?php  echo esc_html__('Bulgarian','gpt-sniper'); ?></option>
                            <option value="Chinese"><?php  echo esc_html__('Chinese','gpt-sniper'); ?></option>
                            <option value="Croatian"><?php  echo esc_html__('Croatian','gpt-sniper'); ?></option>
                            <option value="Czech"><?php  echo esc_html__('Czech','gpt-sniper'); ?></option>
                            <option value="Danish"><?php  echo esc_html__('Danish','gpt-sniper'); ?></option>
                            <option value="Dutch"><?php  echo esc_html__('Dutch','gpt-sniper'); ?></option>
                            <option value="Filipino"><?php echo esc_html__('Filipino','gpt-sniper'); ?></option>
                            <option value="Finnish"><?php  echo esc_html__('Finnish','gpt-sniper'); ?></option>
                            <option value="French"><?php  echo esc_html__('French','gpt-sniper'); ?></option>
                            <option value="German"><?php  echo esc_html__('German','gpt-sniper'); ?></option>
                            <option value="Greek"><?php  echo esc_html__('Greek','gpt-sniper'); ?></option>
                            <option value="Hebrew"><?php  echo esc_html__('Hebrew','gpt-sniper'); ?></option>
                            <option value="Hindi"><?php  echo esc_html__('Hindi','gpt-sniper'); ?></option>
                            <option value="Hungarian"><?php  echo esc_html__('Hungarian','gpt-sniper'); ?></option>
                            <option value="Indonesian"><?php  echo esc_html__('Indonesian','gpt-sniper'); ?></option>
                            <option value="Italian"><?php  echo esc_html__('Italian','gpt-sniper'); ?></option>
                            <option value="Japanese"><?php  echo esc_html__('Japanese','gpt-sniper'); ?></option>
                            <option value="Korean"><?php  echo esc_html__('Korean','gpt-sniper'); ?></option>
                            <option value="Latvian"><?php  echo esc_html__('Latvian','gpt-sniper'); ?></option>
                            <option value="Lithuanian"><?php  echo esc_html__('Lithuanian','gpt-sniper'); ?></option>
                            <option value="Malay"><?php  echo esc_html__('Malay','gpt-sniper'); ?></option>
                            <option value="Norwegian"><?php  echo esc_html__('Norwegian','gpt-sniper'); ?></option>
                            <option value="Polish"><?php  echo esc_html__('Polish','gpt-sniper'); ?></option>
                            <option value="Portuguese"><?php  echo esc_html__('Portuguese','gpt-sniper'); ?></option>
                            <option value="Romanian"><?php  echo esc_html__('Romanian','gpt-sniper'); ?></option>
                            <option value="Russian"><?php  echo esc_html__('Russian','gpt-sniper'); ?></option>
                            <option value="Serbian"><?php  echo esc_html__('Serbian','gpt-sniper'); ?></option>
                            <option value="Slovak"><?php  echo esc_html__('Slovak','gpt-sniper'); ?></option>
                            <option value="Slovenian"><?php  echo esc_html__('Slovenian','gpt-sniper'); ?></option>
                            <option value="panish"><?php  echo esc_html__('panish','gpt-sniper'); ?></option>
                            <option value="Swedish"><?php  echo esc_html__('Swedish','gpt-sniper'); ?></option>
                            <option value="Thai"><?php  echo esc_html__('Thai','gpt-sniper'); ?></option>
                            <option value="Turkish"><?php  echo esc_html__('Turkish','gpt-sniper'); ?></option>
                            <option value="Ukranian"><?php  echo esc_html__('Ukranian','gpt-sniper'); ?></option>
                            <option value="Vietnamese"><?php  echo esc_html__('Vietnamese','gpt-sniper'); ?></option>
                        </select>
                    </div>
                    <div class="gpt-input-wrapper" id="gpt-global-image-filed"> 
                        <label for="bpt_openai_image_size">
                        <?php echo esc_html__('Image Size?','gpt-sniper'); ?>
                        </label>
                        <select name="bpt_openai_image_size" id="bpt_openai_image_size">
                            <option value="256x256"><?php echo esc_html__('Small (256x256)','gpt-sniper'); ?></option>
                            <option value="512x512" selected=""><?php echo esc_html__('Medium (512x512)','gpt-sniper'); ?></option>
                            <option value="1024x1024"><?php echo esc_html__('Big (1024x1024)','gpt-sniper'); ?></option>
                        </select> 
                    </div>
                </div>
                <div class="gpt-col-1">
                    <div class="gpt-input-wrapper">
                        <label for="gpt_add_image">
                        <?php echo esc_html__('Add Image?','gpt-sniper'); ?>
                        </label>
                        <div class="gpt-radio-btn">
                            <input type="checkbox" class="" id="gpt_add_image">
                            <label for="gpt_add_image"><span></span></label>
                        </div> 
                    </div>
                </div>
                <div class="gpt-input-wrapper gpt-content-writer">
                    <label for="">
                    <?php echo esc_html__('Content','gpt-sniper'); ?>
                    </label>
                    <textarea name="gpt_post_content" id="gpt_post_content"><?php echo wp_kses(get_post_meta(get_the_ID(),'gpt_post_content',true),true); ?></textarea>
                </div>
                <div class="gpt-btn-wrap">
                    <a href="javascript:void(0);" class="gpt-btn" id="gpt_sniper_content_writer">
                    <?php echo esc_html__('Generate','gpt-sniper'); ?></a> 
                </div>  
            </div> 
        </div>
    </div> 
    <!-- Loader Section -->
<div class="gpt-preloader" id="gpt-contenttt">
    <img src="<?php echo plugins_url(); ?>/gpt-sniper/admin/images/gpt-loader.svg" alt="<?php echo esc_attr__('loading','gpt-sniper'); ?>">
</div>
</div>