<div class="gpt-shortcode gpt-img-generator">
    <div class="gpt-card">
        <div class="gpt-from-wrapper">
            <div class="gpt-input-wrapper">
                <label for="gpt_image_uset_input_text">
                <?php echo esc_html__('Enter Generate Keyword','gpt-sniper'); ?>
                </label>
                <input type="text" name="gpt_image_uset_input_text" id="gpt_image_uset_input_text" placeholder="<?php echo esc_attr__('Enter Generate Keyword','gpt-sniper'); ?>" />
            </div>
            <!-- Col Two  -->
            <div class="gpt-col-2">
                <div class="gpt-input-wrapper">
                    <label for="gpt_image_size">
                        <?php echo esc_html__('Size','gpt-sniper'); ?>
                    </label>
                    <select name="gpt_image_size" id="gpt_image_size">
                        <option value="256x256"><?php echo esc_html__('256x256','gpt-sniper'); ?></option>
                        <option value="512x512" selected=""><?php echo esc_html__('512x512','gpt-sniper'); ?></option>
                        <option value="1024x1024"><?php echo esc_html__('1024x1024','gpt-sniper'); ?></option>
                    </select>
                </div>
                <div class="gpt-input-wrapper">
                    <label for="gpt_image_number_of">
                        <?php echo esc_html__('Number Of Image','gpt-sniper'); ?>
                    </label>
                    <select name="gpt_image_number_of" id="gpt_image_number_of">
                        <option value="1"><?php echo esc_html__('1','gpt-sniper'); ?></option>
                        <option value="2"><?php echo esc_html__('2','gpt-sniper'); ?></option>
                        <option value="3" selected=""><?php echo esc_html__('3','gpt-sniper'); ?></option>
                        <option value="4"><?php echo esc_html__('4','gpt-sniper'); ?></option>
                        <option value="5"><?php echo esc_html__('5','gpt-sniper'); ?></option>
                        <option value="6"><?php echo esc_html__('6','gpt-sniper'); ?></option>
                        <option value="7"><?php echo esc_html__('7','gpt-sniper'); ?></option>
                        <option value="8"><?php echo esc_html__('8','gpt-sniper'); ?></option>
                        <option value="9"><?php echo esc_html__('9','gpt-sniper'); ?></option>
                        <option value="10"><?php echo esc_html__('10','gpt-sniper'); ?></option>
                    </select>
                </div>
            </div>
            <div class="gpt-btn-wrapper">
                <a href="javascript:void(0);" id="gpt_image_generate" class="gpt-btn">
                    <?php echo esc_html__('Generate','gpt-sniper'); ?>
                </a>
            </div>
            <div class="gpt-image-results"></div>
        </div>
    </div>
    <!-- Loader Section -->
    <div class="gpt-preloader" id="gpt-imagess">
        <img src="<?php echo plugins_url(); ?>/gpt-sniper/admin/images/gpt-loader.svg" alt="<?php echo esc_attr__('loading','gpt-sniper'); ?>">
    </div> 
</div> 