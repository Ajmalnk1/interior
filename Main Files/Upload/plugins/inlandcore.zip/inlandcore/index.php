<?php
/**
 * Plugin Name: Inland Core Plugin 
 * Plugin URI: https://kamleshyadav.com/wp/inland/
 * Description: This plugin create custom post type and some meta option and Shortcode .
 * Version: 1.0.3 
 * Text Domain: inland
 * Author: kamleshyadav
 * Author URI: https://themeforest.net/user/kamleshyadav
 */ 
global $inland_plug_version;
$inland_plug_version = '1.0.2';
remove_action( 'wp_head', 'rest_output_link_wp_head');
/**
 * Admin Enqueue Scripts
 */ 
add_action( 'admin_enqueue_scripts', 'inland_widget_upload_script' );
function inland_widget_upload_script($hook) {
    if ( 'widgets.php' != $hook ) {
        return;
    }
    wp_enqueue_media();
}
/**
 * plugin script enqueue
 */ 
add_action( 'wp_enqueue_scripts', 'inland_pluginscript_enqueue' );
function inland_pluginscript_enqueue(){
    wp_enqueue_style( 'toastr', plugin_dir_url( __FILE__ ) . 'assets/css/toastr.min.css', array(), '1', 'all' , true );
    wp_enqueue_script( 'toastr', plugin_dir_url( __FILE__ ) . 'assets/js/toastr.min.js', array('jquery'), '20151215', true );
    wp_enqueue_script( 'inland-custom-ajax', plugin_dir_url( __FILE__ ) . 'assets/js/inland-custom-ajax-script.js', array('jquery'), '20151215', true );
    // Localize the script with new data
    wp_localize_script( 'inland-custom-ajax', 'frontadminajax', array('ajax_url' => admin_url( 'admin-ajax.php' )) );
} 
/** 
 * inland custom Widget settings
 */
require_once 'vendor/inland-widget.php';

/** 
 * inland custom post settings
 */
require_once 'vendor/inland-custom-setting.php';

/** 
 * inland ajax function
 */
require_once 'vendor/inland-ajax-function.php';

/** 
 * inland custom post type
 */
require_once 'vendor/inland-custom-posttype.php';

function inland_shortcode_extensions($locations) {
	$locations[
		dirname(__FILE__) . '/vendor/extensions'
	] = plugin_dir_url( __FILE__ ) . 'vendor/extensions';

   return $locations;
}
add_filter('fw_extensions_locations','inland_shortcode_extensions');

/**
 *inland theme custom fw settings
 */
add_action('fw_backend_add_custom_settings_menu', 'inland_action_theme_custom_fw_settings_menu');
function inland_action_theme_custom_fw_settings_menu($data) {
    add_menu_page(
        esc_html__('Inland Options', 'inland' ),
        esc_html__('Inland Options', 'inland' ),
        $data['capability'],
        $data['slug'],
        $data['content_callback']
      );
}
/**
 * Inland Demo Content Important
 */
if(!function_exists('_action_fw_plugin_activate')){
function inland_filter_fw_ext_backups_demos($demos){
    
	$demos_array = array(
	    'demo_one' => array(
            'title' => esc_html__('Inland Demo One', 'inland'),
            'screenshot' => 'http://kamleshyadav.com/wp/inland/data/images/demo_one.jpg',
            'preview_link' => 'http://kamleshyadav.com/wp/inland/',
    	       ), 
    	'demo_two' => array(
            'title' => esc_html__('Inland Demo Two', 'inland'),
            'screenshot' => 'http://kamleshyadav.com/wp/inland/data/images/demo_two.jpg',
            'preview_link' => 'http://kamleshyadav.com/wp/inland/home-two/',
    	       ),  
    	'demo_three' => array(
            'title' => esc_html__('Inland Demo Three', 'inland'),
            'screenshot' => 'http://kamleshyadav.com/wp/inland/data/images/demo_three.jpg',
            'preview_link' => 'http://kamleshyadav.com/wp/inland/home-three/',
    	       ),  
    	'demo_four' => array(
            'title' => esc_html__('Inland Demo Four', 'inland'),
            'screenshot' => 'http://kamleshyadav.com/wp/inland/data/images/demo_four.jpg',
            'preview_link' => 'http://kamleshyadav.com/wp/inland/home-four/',
    	       ),  
    	'demo_five' => array(
            'title' => esc_html__('Inland Demo Five', 'inland'),
            'screenshot' => 'http://kamleshyadav.com/wp/inland/data/images/demo_five.jpg',
            'preview_link' => 'http://kamleshyadav.com/wp/inland/home-five/',
    	       ),
		'demo_six' => array(
            'title' => esc_html__('Inland Demo Rtl', 'inland'),
            'screenshot' => 'http://kamleshyadav.com/wp/inland/data/images/demo_six.jpg',
            'preview_link' => 'https://kamleshyadav.com/wp/inland/rtl/',
    	       ),
    );
    foreach ($demos_array as $id => $data) {
		$demo = new FW_Ext_Backups_Demo($id, 'piecemeal', array(
			'url' => 'http://kamleshyadav.com/wp/inland/data/themedemo',
			'file_id' => $id,
		));  
		$demo->set_title($data['title']);
		$demo->set_screenshot($data['screenshot']);
		$demo->set_preview_link($data['preview_link']);
        $demos[$demo->get_id()] = $demo;
        unset($demo);
	} 
   return $demos;  
}
$dir = get_template_directory().'/demo-content';
if(!is_dir($dir)):
add_filter('fw:ext:backups-demo:demos','inland_filter_fw_ext_backups_demos');  
endif;
}

/**
 * Removing Buttons
 */ 

add_action( 'woocommerce_widget_shopping_cart_buttons', function(){
    // Removing Buttons
    remove_action( 'woocommerce_widget_shopping_cart_buttons', 'woocommerce_widget_shopping_cart_button_view_cart', 10 );
    remove_action( 'woocommerce_widget_shopping_cart_buttons', 'woocommerce_widget_shopping_cart_proceed_to_checkout', 20 );

    // Adding customized Buttons
    add_action( 'woocommerce_widget_shopping_cart_buttons', 'inland_widget_shopping_cart_button_view_cart', 10 );
    add_action( 'woocommerce_widget_shopping_cart_buttons', 'inland_widget_shopping_cart_proceed_to_checkout', 20 );
}, 1 );

/**
 * Custom cart button
 */ 
function inland_widget_shopping_cart_button_view_cart() {
    $original_link = wc_get_cart_url();
    $custom_link = home_url( '/cart/' ); // HERE replacing cart link
    echo '<a href="'.esc_url( $custom_link ).'" class="button wc-forward">'. esc_html__('View cart', 'inland').'<span class="btn-caret">
        <i class="fas fa-caret-right"></i></span></a>';
}

/**
 * Custom Checkout button
 */ 
function inland_widget_shopping_cart_proceed_to_checkout() {
    $original_link = wc_get_checkout_url();
    $custom_link = home_url( '/checkout/' ); // HERE replacing checkout link
    
    echo '<a href="'.esc_url($custom_link).'" class="button checkout wc-forward">'.esc_html__( 'Checkout', 'inland' ).'<span class="btn-caret"><i class="fas fa-caret-right"></i></span></a>';
}

/**
 * add demo import time custom class
 */ 
add_filter( 'body_class','inland_man_body_classes' );
function inland_man_body_classes( $classes ) {
    
    $themeoption_data = '';
    if(function_exists('fw_get_db_settings_option')){
      $themeoption_data = fw_get_db_settings_option();
    }

    $demoimport = '';
    if(!empty($themeoption_data['demoimport'])){
      $demoimport = $themeoption_data['demoimport'];
    }
    if($demoimport == "on") {
      $classes[] = 'demo-import';
    }else{
      $classes[] = '';
    }
    return $classes;
}