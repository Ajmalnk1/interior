jQuery(document).ready(function($) {
    "use strict"; 
    /**
     * inland user register form
     */ 
    $("#inland_register").on('click', function(e){
		e.preventDefault();
		var username = $("#usernames").val();
		var full_name = $("#full_name").val();
		var useremail = $("#useremail").val();
		var password = $("#us_password").val();
		var confirmpass = $("#us_cpassword").val();
		var emptyfield = false;
		var emailvalid = false;
		var passvalid = false;
		toastr.clear();

		if( username == '' ) {
			emptyfield = true;
		}
		if(full_name == '') {
			emptyfield = true;
		}
		if(useremail == '') {
			emptyfield = true;
		}
		if(password == '') {
			emptyfield = true;
		}
		if(confirmpass == '') {
			emptyfield = true;
		}

		if(emptyfield == false) {
			if ( validateEmail(useremail) ) {
				emailvalid = true;
			}else {
				emailvalid = false;
				toastr.error('Email is not valid.');
	        }

	        if(password == confirmpass){
	        	passvalid = true;
	        }else{
	        	passvalid = false;
	        	toastr.error('password does not match.');
	        }

		}else{
			$(".form-msg").addClass('error-row');
			toastr.error('All fields are required.');
		}

		if(passvalid == true && emailvalid == true) {
			var formdata ='username='+username+'&full_name='+full_name+'&useremail='+useremail+'&password='+password+'&confirmpass='+confirmpass;
				formdata += '&action=inland_user_register_form';

				$("#erroremail").html('');
				$("#errorcpass").html('');
				$("#register_btn").hide();
				$(".hst_loader").show();
				$(".form-msg").html('');
				$.ajax({
					type: 'post',
					url: frontadminajax.ajax_url,
					data: formdata,
					success: function(response){
						var result = JSON.parse(response);
						if( result.status == 'true' ) {
							$(".form-msg").addClass('success-row');
							toastr.success(result.msg);
							$("#form_register")[0].reset();
							$("#myModal").modal("hide");
							$("#myModal1").modal("show");
						}else{
							$.each(result, function(i,n){
							    if(n != 'false'){
							        toastr.error(n);   
							    }
							});
						}

						$(".hst_loader").hide();
						$("#register_btn").show();

					}
				});
		}


	});
    
    /**
     * inland user login form
     */ 
    $("#inland_login").on('click', function(e){
	e.preventDefault();
	var username = $("#lusernames").val();
	var password = $("#lpassword").val();
	var rem = $('#rem_check').val();
    toastr.clear();
		if(username == '' && password == ''){
			$(".form-lmsg").addClass('error-row');
			toastr.error('All fields are required.');
		}else{
			var formdata ='username='+username+'&password='+password+'&rem_check='+rem;
			formdata += '&action=inland_user_login_form';

			$("#login_btn").hide();
			$(".hst_loader").show();
			$(".form-lmsg").html('');
			$.ajax({
				type: 'post',
				url: frontadminajax.ajax_url,
				data: formdata,
				success: function(response){
					var result = JSON.parse(response);
					if( result.status == 'false' ) {
						$(".form-lmsg").addClass('error-row');
						toastr.error(result.msg);
					}else{
					    toastr.success(result.msg);
						window.location.href = result.redirect_uri;
					}
					
					$(".hst_loader").hide();
					$("#login_btn").show();

				}
			});
		}

	});
    
    /**
     * Inland Gallery load More
     */ 
    $('#inland_loadmore').on('click',function(){
        var ajx_auto_incriment = jQuery(".ajx_auto_incriment").val();
        var ajx_blog_number = jQuery(".ajx_blog_number1").val();
		var ajx_blog_showmore = jQuery(".ajx_blog_showmore1").val();
		var ajx_multi = ajx_blog_showmore*ajx_auto_incriment;
		var numbergallery = parseInt(ajx_blog_number) + parseInt(ajx_multi);
		ajx_auto_incriment++;
		
        var catid = jQuery('.active').attr('data-catname');
      
       var formdata ='numbergallery='+numbergallery+'&catid='+catid;
	   formdata += '&action=inland_load_posts_by_ajax_callback';
       $.ajax({
			type: 'post',
			url: frontadminajax.ajax_url,
			data: formdata,
            success: function(response){
               
				$('#inland_gallery_loadermore').html(response); 
				$('.view').magnificPopup({
					  type: 'image',
					  gallery: {
						enabled: true
					  }
					});
            }
       }); 
    });
  
$(".vt_catvalue").on('click',function(){ 
       $('.vt_tab_menus a').removeClass("active");
	   $(this).addClass('active')
	   var catename = $(this).attr('data-catname');
	   var $showgallery = 3;
	   var formdata = 'click_value='+catename;
	   formdata += '&action=inland_load_posts_by_category';
	    
		    $.ajax({
				type : "post", 
				url : frontadminajax.ajax_url,
				data : formdata, 
				success: function(response) {
				    console.log(response);
				    $("#inland_gallery_loadermore").html(response);
				    $('.view').magnificPopup({
					  type: 'image',
					  gallery: {
						enabled: true
					  }
					});
				}
			})
				
    	});
    	
    	/**
     * add cart button message
     */ 
    $('.ss_pordut_cart').on('click',function(){
        
        if($(this).attr('data-productid')){
            
            toastr.success('Add Cart Successfully');
            
        }
        
    });
    
    /**
     * add to wishlist message
     */
    $('.ss_pordut_wl').on('click', function(){
        
        if($(this).attr('data-productid')){
            
            toastr.success('Added In Wishlist');
            
        }
        
    });
    
    	 
   /**
	* email checker
	*/ 
    function validateEmail(uemail) {
        var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
	    if (filter.test(uemail)) {
	        return true;
	    }
	    else {
	        return false;
	    }
    }
    
    /**
     * mailchimp jquery
     */ 
	$('#ss_newslatter').on('click',function(e) {
        e.preventDefault();
	    var subc_email = $("#ns_email").val();
        var apikey = $("#ns_apikey").val();
        var listid = $("#ns_list").val();
		if (!validateEmail(subc_email))
        {  
         $(".ss_messages").html("<span style='color:red;'>Please make sure you enter a valid email address.</span>");
        }else{
		    jQuery.ajax({ 
			    type : "post",
                url : frontadminajax.ajax_url,
                data : {'action': "inland_send_newsletter", apikey : apikey,listid:listid,subc_email:subc_email}, 
				success: function(response) {
				    console.log(response);
                           if(response=="200" ){
                               $(".ss_messages").html('<span style="color:green;">You have successfully subscribed to our mailing list.</span>');
							 } else if(response=="204"){
                                $(".ss_messages").html('<span style="color:red;">Your Email Alreday Subscribed List</span>');  
							 }else{
							  $(".ss_messages").html('<span style="color:red;">Please Check Email Address</span>');  
							}
						}
                  });
	        }
	 });
}); 