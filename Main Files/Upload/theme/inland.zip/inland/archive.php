<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package inland
 */
get_header();
?>
<div id="primary" class="content-area">
	<main id="main" class="site-main">
		<?php
		/**
		 * inland Archive content area
		 */
		$inland_setting = '';
		if(class_exists('Inland_Themesetting')):
			$inland_setting = new Inland_Themesetting();
			/** * Theme blog */
			if(!function_exists('inland_index_blog')):
				$inland_setting->inland_index_blog(get_the_ID());
			endif;
		endif;
		?>
	</main><!-- #main -->
</div><!-- #primary -->
<?php
get_footer();