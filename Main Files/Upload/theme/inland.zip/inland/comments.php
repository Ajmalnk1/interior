<?php
/**
 * The template for displaying comments
 *
 * This is the template that displays the area of the page that contains both the current comments
 * and the comment form.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package inland
 */
/*
 * If the current post is protected by a password and
 * the visitor has not yet entered the password we will
 * return early without loading the comments.
 */
if ( post_password_required() ) {
	return;
}
?>
<div id="comments" class="comments-area it-blog-comment-box">
	<?php
	// You can start editing here -- including this comment!
	if ( have_comments() ) :
		?>
		<h1 class="comments-title">
			<?php
			$inland_comment_count = get_comments_number();
			
			if(!empty($inland_comment_count)):
			     if($inland_comment_count > 1):
					printf( // WPCS: XSS OK.
					/* translators: 1: comment count number, 2: title. */
					esc_html( '%1$s Comments', 'inland'),
					number_format_i18n( $inland_comment_count )
			    	);
			     else:
			         printf( // WPCS: XSS OK.
					/* translators: 1: comment count number, 2: title. */
					esc_html( '%1$s Comment', 'inland'),
					number_format_i18n( $inland_comment_count )
			    	);
			     endif;
			endif;	
			?>
		</h1><!-- .comments-title -->
		<?php the_comments_navigation(); ?>
		<ol class="comment-list">
			<?php
			wp_list_comments( array(
				'style'      => 'ol',
				'short_ping' => true,
				'avatar_size' => 61,
				'callback'   => 'inland_comment_callback',
			) );
			?>
		</ol><!-- .comment-list -->
		<?php
		the_comments_navigation();
		// If comments are closed and there are comments, let's leave a little note, shall we?
		if ( ! comments_open() ) :
			?>
			<p class="no-comments"><?php esc_html_e( 'Comments are closed.', 'inland' ); ?></p>
			<?php
		endif;
	endif; // Check for have_comments().
	?>
	<div class="it-blog-form">
	<?php
	$args = array(
	    'fields' => apply_filters(
		    'comment_form_default_fields', array(
                'author' =>'<div class="row">
                             <div class="col-md-6 col-lg-6">
                			  <div class="form-block">
                			   <input type="text" id="author" name="author" value="'.esc_attr( $commenter['comment_author'] ).
		               '" class="form-field" placeholder="'.esc_attr__('Your Name','inland').'" >
                		 	</div>
                		 </div>',
                'email' =>'<div class="col-md-6 col-lg-6">
                			<div class="form-block">
                			 <input type="text" id="email" name="email" class="form-field" value="'.esc_attr($commenter['comment_author_email']).
		              '" placeholder="'.esc_attr__('Your Email','inland').'" >
                			</div>
                		  </div>
                		</div>'
                   )
            ),
            'comment_field' =>'<div class="row">
                            <div class="col-md-12 col-lg-12">
            			     <div class="form-block">
            			 	  <textarea placeholder="'.esc_attr__('Your Comment', 'inland').'" id="comment" name="comment" class="form-field" ></textarea>
            			   </div>
            		     </div>
            		  </div>',
	 	   'submit_field'	=> '<p class="it-form-submit">%1$s %2$s
             <span class="btn-caret"><i class="fas fa-caret-right"></i></span></p>
            ',
            'id_submit'	=> 'comment-submit',
    	   'class_submit'	=> 'it-btn',
    	   'name_submit'	=> 'submit',
	       );
	    comment_form($args);
	   ?>
	</div>
</div><!-- #comments -->