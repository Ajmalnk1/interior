/*--------------------- Copyright (c) 2019 -----------------------
[Master Javascript]
Project: Inland Design - Multipurpose Responsive HTML Template
Version: 1.0.0
Assigned to: Theme Forest
-------------------------------------------------------------------*/
(function($) {
    "use strict";
    var Inland = {
        initialised: false,
        version: 1.0,
        mobile: false,
        init: function() {

        if (!this.initialised) {
            this.initialised = true;
        } else {
            return;
        }

        /*-------------- Inland Design Functions Calling ---------------------------------------------------
        ------------------------------------------------------------------------------------------------*/
        this.it_menu_toggle();
        this.Open_cartbox();
        this.list_radio();
        this.preLoader();
        this.Search_bar_input();
        this.Login_popup();
        this.Isotop_gallery();
        this.Magnific_popup();
        this.Video_popup();
        this.Progress_bar();
        this.Counter();
        this.PriceRange();
        this.ListGridView();
        this.Quantity();
        this.date_picker();
        this.Sign_slider();
        this.index3_client_slider();
        this.Dark_testimonial();
        this.Team_slider();
        this.it_testimonial_slide2();
        this.index3_testimonial();
        this.index4_testimonial_slider();
        this.Product_slider();
        this.RelatedProduct();
        this.tiltAnimation();
		this.Mouse_wheel();

      },

        /*-------------- Inland Design Functions Calling ---------------------------------------------------
        ---------------------------------------------------------------------------------------------------*/
        // MENU JS START

        it_menu_toggle: function() {

            var counter = 0;
            $('.it-toggle').on("click", function(e) {
                e.stopPropagation();
                if (counter == '0') {
                    $('.it-menu').addClass('it-menu-open');
                    $(this).children().removeAttr('class');
                    $(this).children().attr('class', 'fas fa-times');
                    counter++;
                } else {
                    $('.it-menu').removeClass('it-menu-open');
                    $(this).children().removeAttr('class');
                    $(this).children().attr('class', 'fas fa-bars');
                    counter--;
                }
            });

            $('body').on('click', function() {
                $('.it-menu').removeClass('it-menu-open');
                $('.it-toggle').children().removeAttr('class');
                $('.it-toggle').children().attr('class', 'fas fa-bars');
            });

            $('.it-menu').click(function(event) {
                event.stopPropagation();
            });

            $(".it-menu ul li.menu-item-has-children").toggleClass(function() {
                $(this).children('a').append(function() {
                    return '<div class="dropdown-expander"><i class="subdropdown fa fa-angle-down" aria-hidden="true"></i></div>';
                });
            });

            $(".subdropdown").on('click', function() {
                var minus = $(this).hasClass("fa-angle-down");
                if (minus == true) {
                    $(this).removeClass("fa-angle-down");
                    $(this).addClass("fa-angle-up");
                } else {
                    $(this).addClass("fa-angle-down");
                    $(this).removeClass("fa-angle-up");
                }

            });
            $(".it-menu ul > li:has(ul)").addClass('has-sub-menu');
            $(".it-menu ul > li:has(ul) > a").on('click', function(e) {
                var w = window.innerWidth;
                if (w <= 991) {
                    e.preventDefault();
                    $(this).parent('.it-menu ul li.has-sub-menu').toggleClass('sub-menu-open');
                    $(this).parent('.it-menu ul li').children('ul.sub-menu').slideToggle();
                }
            });

        },
        
         preLoader: function() {
            jQuery(window).on('load', function() {
                jQuery(".status").fadeOut();
                jQuery(".preloader").delay(350).fadeOut("slow");
            });
        },
        
        // start cartbox open toggle
        list_radio: function() {
            $('.it-credit-dark').on('click', function() {
                $('.active2').removeClass('active2');
                $(this).addClass('active2').find('input').prop('checked', true)
            });
            $('.it-credit-white').on('click', function() {
                $('.active').removeClass('active');
                $(this).addClass('active').find('input').prop('checked', true)
            });

        },

        Open_cartbox: function() {
            $(".box-add").on('click', function(e) {
                e.stopPropagation();
                $("body").toggleClass('open-cart');
            });
            $('body').on('click', function() {
                $('body').removeClass('open-cart');
            });
            $('.header-cartbox').on('click', function(event) {
                event.stopPropagation();
            });

        },

        // End cartbox open toggle

        // Search bar box js
        Search_bar_input: function() {
            $('.open-search-bar').on('click', function() {
                $('body').addClass('close-search-bar');
            });
            $('.fa-times').on('click', function() {
                $('body').removeClass('close-search-bar');
            });

            $('.setting-toggle').on('click', function() {
                $('.it-profile-open').toggleClass('it-profile-drop');
            });

        },
        // Search bar box js	

        // Sign up Model js	
        Login_popup: function() {
            $('.it-login-model').on('click', function() {
                $('.it-modal-login').addClass('open-login-model');
            });
            $('.close-login').on('click', function() {
                $('.it-modal-login').removeClass('open-login-model');
            });
            $('.it-modal-form').on('click', function() {
                $('.it-modal-login').removeClass('open-login-model');
            });
            $(".it-signin-flex").on('click', function () {
				event.stopPropagation();
			});
            $('.it-signup-model').on('click', function() {
                $('.it-modal-signup').addClass('open-signup-model');
            });
            $('.close-login,.it-modal-signup').on('click', function() {
                $('.it-modal-signup').removeClass('open-signup-model');
            });
        },

        // Star isotop gallery js 

        Isotop_gallery: function() {

            $(window).on('load', function() {

                $('.gallery-grid').isotope({
                    itemSelector: '.grid-item',
                    filter: '*'
                });
                $('.it-project-gallery > .gallery-nav > ul > li').on('click', 'a', function() {
                    // filter button click
                    var filterValue = $(this).attr('data-filter');
                    $('.gallery-grid').isotope({
                        filter: filterValue
                    });

                    //active class added
                    $('a').removeClass('gallery-active');
                    $(this).addClass('gallery-active');
                });



            });


        },
       
        // Star isotop gallery js 

        // magnifiv popup for project gallery
        Magnific_popup: function() {
            if ($('.view').length > 0) {
                $('.view').magnificPopup({
                    type: 'image',

                    gallery: {
                        // options for gallery
                        enabled: true
                    }

                    // other options
                });
            }
        },
        // magnifiv popup for project gallery

        //video Pop up start
        Video_popup: function() {
            if ($('.it-progresbar-wrapper .video-popup').length > 0) {
                $('.it-progresbar-wrapper .video-popup').magnificPopup({
                    type: 'iframe',
                    iframe: {
                        markup: '<div class="mfp-iframe-scaler">' +
                            '<div class="mfp-close"></div>' +
                            '<iframe class="mfp-iframe" frameborder="0" allowfullscreen></iframe>' +
                            '<div class="mfp-title">Some caption</div>' +
                            '</div>',
                        patterns: {
                            youtube: {
                                index: 'youtube.com/',
                                id: function(url) {
                                    return url
                                },
                                src: '%id%'
                            }
                        }
                    }
                    // other options
                });
            }
        },
        //video Pop up End

        //Progress bar start
        Progress_bar: function() {
            if ($('.it-progresbar-wrapper .progress-bar').length > 0) {
                $(document).ready(function() {
                    const time = 1500;

                    function calculateTime(time, dataCount) {
                        return time / dataCount;
                    }

                    $(".progress-bar").each(function(index) {
                        let count = 0;
                        let label = $(this).children('.label');
                        let line = $(this).children('.line');

                        let dataCount = parseInt(label.attr('data-count'));
                        let lineCount = line.children();
                        let runTime = calculateTime(time, dataCount);
                        setInterval(function() {
                                if (count < dataCount) {
                                    count++;
                                    label.text(count + '%');
                                    lineCount.css('width', count + '%');

                                    if (count < 30) {
                                        lineCount.css('background', '#c6a47e');
                                    } else if (count < 70) {
                                        lineCount.css('background', '#c6a47e');
                                    } else if (count === 100) {
                                        lineCount.css('background', '#c6a47e');
                                    } else {
                                        lineCount.css('background', '#c6a47e');
                                    }
                                }
                            },
                            runTime);
                    });
                });


            }
        },
        
         /*-----------------------------------------------------
		Fix Image Animation
		-----------------------------------------------------*/
        	tiltAnimation: function () {
        				var tiltAnimation = $('.parallax')
        				if (tiltAnimation.length) {
        					tiltAnimation.tilt({
        						max: 12,
        						speed: 1e3,
        						easing: 'cubic-bezier(.03,.98,.52,.99)',
        						transition: !1,
        						perspective: 1e3,
        						scale: 1
        					})
        				}
        			},


        //Progress bar End

        /*------------------------------------------------------------------*/

        //Counter Js start
        Counter: function() {
            if ($('.counter-text').length > 0) {
                $('.counter-text').appear(function() {
                    $('.count-no').countTo();
                });
            }
        },
        //Counter Js end
       // Range Slider start
       
        PriceRange: function() {
            if ($('.range-slider').length > 0) {
                $(function() {
                    $("#slider-range").slider({
                        range: true,
                        min: 12,
                        max: 2000,
                        values: [541, 1402],
                        slide: function(event, ui) {
                            $("#amount").text("$" + ui.values[0] + " - $" + ui.values[1]);
                        }
                    });
                    $("#amount").text("$" + $("#slider-range").slider("values", 0) +
                        " - $" + $("#slider-range").slider("values", 1));
                });
            }
        },
        // Range Slider End

        // List Grid View js start
        ListGridView: function() {
            $('.list-view-toggle > li > a').on('click', function() {
                $('.list-view-toggle > li > a').removeClass('active');
                $(this).addClass('active');
            });
            $('.list-view').on('click', function() {
                $('.it-product-listbar').addClass('product-list-view');
            });
            $('.grid-view').on('click', function() {
                $('.it-product-listbar').removeClass('product-list-view');
            });
        },
        // List Grid View js End

        // Quantity js start
        Quantity: function() {
            var quantity = 0;
            $('.quantity-plus').on('click', function(e) {
                e.preventDefault();
                var quantity = parseInt($(this).siblings('.quantity').val());
                $(this).siblings('.quantity').val(quantity + 1);

            });
            $('.quantity-minus').on('click', function(e) {
                e.preventDefault();
                var quantity = parseInt($(this).siblings('.quantity').val());
                if (quantity > 0) {
                    $(this).siblings('.quantity').val(quantity - 1);
                }
            });
        },
        // Quantity js End

        // datepicker js 
        date_picker: function() {
            $(document).ready(function() {
                $('#datepicker').datepicker({
                    format: "yyyy/mm/dd"
                });
            });
        },
        // datepicker js 

        /*************************   SLIDERS *************************************************/
        
        // Sign-slider js start
            Sign_slider: function() {
                if ($('.related-product.swiper-container').length > 0) {
                    var swiper = new Swiper('.it-sign-slide .swiper-container', {
                        slidesPerView: 1,
                        loop: true,
                        speed: 1000,
                        autoplay: {
                            delay: 2000,
                            disableOnInteraction: false,
                        },
                        pagination: {
                            el: '.swiper-pagination',
                            clickable: true,
                        },
                        navigation: {
                            nextEl: '.it-sign-slide .swiper-button-next',
                            prevEl: '.it-sign-slide .swiper-button-prev',
                        },
                    });
                }
                
                if ($('.it-sign-slide .swiper-container').length > 0) {
                    var swiper = new Swiper('.it-sign-slide .swiper-container', {
                        slidesPerView: 1,
                        loop: true,
                        autoplay: {
                            delay: 2500,
                            disableOnInteraction: false,
                        },
                        speed: 1000,
                        pagination: {
                            el: '.swiper-pagination',
                            clickable: true,
                        },
                        navigation: {
                            nextEl: '.it-sign-slide .swiper-button-next',
                            prevEl: '.it-sign-slide .swiper-button-prev',
                        },
                    });
                }
                
            },
        // Sign-slider js End
        
        // CLIENT  Js start
        index3_client_slider: function() {
            if ($('.it-client-slider').length > 0) {
                var swiper = new Swiper('.it-client-slider .swiper-container', {
                    slidesPerView: 6,
                    spaceBetween: 50,
                    loop: true,
                    autoplay: {
                        delay: 2500,
                        disableOnInteraction: false,
                    },
                    breakpoints: {
                        1024: {
                            slidesPerView: 4,
                            spaceBetween: 30,
                        },
                        768: {
                            slidesPerView: 3,
                            spaceBetween: 30,
                        },
                        640: {
                            slidesPerView: 2,
                            spaceBetween: 20,
                        },
                        320: {
                            slidesPerView: 2,
                            spaceBetween: 10,
                        }
                    }
                });
            }
        },
        
        // CLIENT  Js End
        
        //team slider start
        Team_slider: function() {
            if ($('.teamSliderFirst.swiper-container').length > 0) {
                var swiper = new Swiper('.team-box-wrapper .swiper-container', {
                    slidesPerView: 4,
                    spaceBetween: 30,
                    freeMode: true,
                    speed: 1000,
                    loop: true,
                    autoplay: true,
                    navigation: {
                        nextEl: '.it-team-wrapper .swiper-button-next',
                        prevEl: '.it-team-wrapper .swiper-button-prev',
                    },
                    pagination: {
                        el: '.it-team-wrapper .swiper-pagination',
                        clickable: true,
                    },
                    breakpoints: {
                        1024: {
                            slidesPerView: 2,
                            spaceBetween: 30,
                        },
                        768: {
                            slidesPerView: 2,
                            spaceBetween: 30,
                        },
                        640: {
                            slidesPerView: 1,
                            spaceBetween: 20,
                        },
                        320: {
                            slidesPerView: 1,
                            spaceBetween: 10,
                        }
                    }

                });
            }
        },
        //team slider start

         //team2 slider start
        Team_slider_two: function() {

                var swiper1 = new Swiper('.swiper-container.teamSliderSecond', {
                    freeMode: true,
                    centeredSlides: false,
                    speed: 1000,
                    slidesPerView: 3,
                    spaceBetween: 30,
                    loop: true,
                    autoplay:true,
                    autoplay: {
                        delay: 2500,
                        disableOnInteraction: false,
                    },
                    navigation: {
                        nextEl: '.teamSliderSecondWrapper .swiperButtonNext',
                        prevEl: '.teamSliderSecondWrapper .swiperButtonPrev',
                    },
                    breakpoints: {
                        575: {
                            slidesPerView: 1,
                            spaceBetween: 0,
                        },
                        768: {
                            slidesPerView: 2,
                            spaceBetween: 15,
                        },
                        991: {
                            slidesPerView: 3,
                            spaceBetween: 15,
                        },
                        992: {
                            slidesPerView: 3,
                            spaceBetween: 15,
                        },
                        1199: {
                            slidesPerView: 3,
                            spaceBetween: 15,
                        },
                        1200: {
                            slidesPerView: 3,
                            spaceBetween: 30,
                        },
                         1920: {
                            slidesPerView: 3,
                            spaceBetween: 30,
                        },
                    }

                });
            
        },
        //team2 slider end
        
        //Dark Testimonial
        Dark_testimonial: function() {
            $(window).on("load", function() {
                var galleryThumbs = new Swiper('.it-testimonial-wrapper .gallery-thumbs', {
                    spaceBetween: 15,
                    slidesPerView: 3,
                    loop: true,
                    speed: 800,
                    centeredSlides: true,
                    allowTouchMove: false,
                    effect: 'coverflow',
                    coverflowEffect: {
                        rotate: 0,
                        stretch: 10,
                        depth: 0,
                        modifier: 1,
                        slideShadows: false
                    },
                    breakpoints: {
                        1024: {
                            slidesPerView: 3,
                            spaceBetween: 30,
                        },
                        767: {
                            slidesPerView: 2,
                            spaceBetween: 20,
                        },
                        640: {
                            slidesPerView: 1,
                            spaceBetween: 20,
                        },
                        320: {
                            slidesPerView: 1,
                            spaceBetween: 10,
                        }
                    }


                });

                var galleryTop = new Swiper('.it-testimonial-wrapper .gallery-top', {
                    spaceBetween: 10,
                    slidesPerView: 1,
                    loop: true,
                    allowTouchMove: false,
                    speed: 800,
                    slidesPerView: 1,
                    autoplay: {
                        delay: 2500,
                        disableOnInteraction: false,
                    },
                    thumbs: {
                        swiper: galleryThumbs,
                    },
                    pagination: {
						el: '.it-testimonial-wrapper .swiper-pagination',
						clickable: true,
					},
                });

            });
        },

        //Dark Testimonial

        //Testimonial2 slider start
        it_testimonial_slide2: function() {
            if ($('.it-testimonial-slide2 .swiper-container').length > 0) {
                var swiper = new Swiper('.it-testimonial-slide2 .swiper-container', {
                    loop: true,
                    speed: 2000,
                    slidesPerView: 1,
                    autoplay: true,
                    navigation: {
                        nextEl: '.it-testimonial-slide2 .swiper-button-next',
                        prevEl: '.it-testimonial-slide2 .swiper-button-prev',
                    },
                });
            }
        },
        
        //Testimonial2 slider end
        
        //Index 3 Testimonial
        index3_testimonial: function() {
            if ($('.it-testimonial-style3').length > 0) {
                var galleryThumbs = new Swiper('.it-testimonial-style3 .gallery-thumbs', {
                    spaceBetween: 50,
                    slidesPerView: 3,
                    loop: true,
                    speed: 1000,
                    centeredSlides: true,
                    allowTouchMove: false,
                    effect: 'coverflow',
                    coverflowEffect: {
                        rotate: 0,
                        stretch: 10,
                        depth: 0,
                        modifier: 1,
                        slideShadows: false
                    },
                    breakpoints: {
                        1024: {
                            slidesPerView: 3,
                            spaceBetween: 30,
                        },
                        768: {
                            slidesPerView: 3,
                            spaceBetween: 20,
                        },
                        767: {
                            slidesPerView: 1,
                            spaceBetween: 20,
                        },
                        640: {
                            slidesPerView: 1,
                            spaceBetween: 20,
                        },
                        320: {
                            slidesPerView: 1,
                            spaceBetween: 10,
                        }
                    }


                });

                var galleryTop = new Swiper('.it-testimonial-style3 .gallery-top', {
                    spaceBetween: 10,
                    loop: true,
                    allowTouchMove: false,
                    speed: 1000,
                    slidesPerView: 1,
                    autoplay: {
                        delay: 2500,
                        disableOnInteraction: false,
                    },
                    thumbs: {
                        swiper: galleryThumbs,
                    },
                });
            }
        },
        //Index 3 Testimonial

        // Index4 Testimonial Slider
        index4_testimonial_slider: function() {
            if ($('.it-testimonial-style4 .swiper-container').length > 0) {
                var swiper = new Swiper('.it-testimonial-style4 .swiper-container', {
                    loop: true,
                    speed: 1000,
                    effect: 'fade',
                    slidesPerView: 1,
                    autoplay: {
                        delay: 2500,
                        disableOnInteraction: false,
                    },
                    pagination: {
                        el: '.it-testimonial-style4 .swiper-pagination',
                        clickable: true,
                    },
                });

            }
        },
        // Index4 Testimonial Slider

        //Product Slider Js start
        Product_slider: function() {
            if ($('.it-product-slider-box').length > 0) {
                var swiper = new Swiper('.it-product-slider-box .swiper-container', {
                    slidesPerView: 4,
                    spaceBetween: 30,
                    loop: true,
                    speed: 2000,
                    autoplay: {
                        delay: 2500,
                        disableOnInteraction: false,
                    },
                    pagination: {
                        el: '.it-product-slider-box .swiper-pagination',
                        clickable: true,
                    },
                    breakpoints: {
                        1199: {
                            slidesPerView: 4,
                            spaceBetween: 40,
                        },
                        991: {
                            slidesPerView: 3,
                            spaceBetween: 30,
                        },
                        768: {
                            slidesPerView: 2,
                            spaceBetween: 20,
                        },
                        575: {
                            slidesPerView: 1,
                            spaceBetween: 10,
                        }
                    }
                });
            }
        },
        //Product Slider Js end
        
        // start related product slider
        RelatedProduct: function() {
            if ($('.related-product.swiper-container').length > 0) {
                var swiper = new Swiper('.related-product.swiper-container', {
                    speed: 1000,
                    loop: false,
                    spaceBetween: 30,
                    autoplay: true,
                    slidesPerView: 4,
                    pagination: {
                        el: '.related-product-page .swiper-pagination',
                        clickable: true,
                    },
                    breakpoints: {
                        1024: {
                            slidesPerView: 2,
                            spaceBetween: 30,
                        },
                        768: {
                            slidesPerView: 2,
                            spaceBetween: 30,
                        },
                        640: {
                            slidesPerView: 1,
                            spaceBetween: 20,
                        },
                        320: {
                            slidesPerView: 1,
                            spaceBetween: 10,
                        },
                    },
    
                });
            }

        },
        // end related product slider

		/*Mouse_wheel*/
		Mouse_wheel:function(){
			if ($(window).width() >= 1699){	
				var swiper = new Swiper('.mouse-wheel-slide .swiper-container', {
					slidesPerView: 1,
					mousewheel: true,
					direction: 'vertical',
					parallax: true,
					speed: 1500,
					autoHeight: false,
					pagination: {
					  el: '.mouse-wheel-slide .swiper-pagination',
					  clickable: true,
					},
					
				});
			};
			$(window).resize(function(){
				var width = $(window).width();
				if(width < 1699){
					$('.it-vertical-slider').removeClass('swiper-slide');
				}
			})
			.resize();	
			$(window).resize(function(){
				var width = $(window).width();
				if(width < 1699){
					$('.it-vertical-slider').removeClass('swiper-container');
				}
			})
			.resize();	
			$(window).resize(function(){
				var width = $(window).width();
				if(width < 1699){
					$('.it-vertical-slider').removeClass('swiper-wrapper');
				}
			})
			.resize();			
		},

        /*************************   SLIDERS END *************************************************/


    };
    Inland.init();



    // Contact Form Submission
    function checkRequire(formId, targetResp) {
        targetResp.html('');
        var email = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/;
        var url = /(http|ftp|https):\/\/[\w-]+(\.[\w-]+)+([\w.,@?^=%&amp;:\/~+#-]*[\w@?^=%&amp;\/~+#-])?/;
        var image = /\.(jpe?g|gif|png|PNG|JPE?G)$/;
        var mobile = /^[\s()+-]*([0-9][\s()+-]*){6,20}$/;
        var facebook = /^(https?:\/\/)?(www\.)?facebook.com\/[a-zA-Z0-9(\.\?)?]/;
        var twitter = /^(https?:\/\/)?(www\.)?twitter.com\/[a-zA-Z0-9(\.\?)?]/;
        var google_plus = /^(https?:\/\/)?(www\.)?plus.google.com\/[a-zA-Z0-9(\.\?)?]/;
        var check = 0;
        $('#er_msg').remove();
        var target = (typeof formId == 'object') ? $(formId) : $('#' + formId);
        target.find('input , textarea , select').each(function() {
            if ($(this).hasClass('require')) {
                if ($(this).val().trim() == '') {
                    check = 1;
                    $(this).focus();
                    $(this).parent('div').addClass('form_error');
                    targetResp.html('You missed out some fields.');
                    $(this).addClass('error');
                    return false;
                } else {
                    $(this).removeClass('error');
                    $(this).parent('div').removeClass('form_error');
                }
            }
            if ($(this).val().trim() != '') {
                var valid = $(this).attr('data-valid');
                if (typeof valid != 'undefined') {
                    if (!eval(valid).test($(this).val().trim())) {
                        $(this).addClass('error');
                        $(this).focus();
                        check = 1;
                        targetResp.html($(this).attr('data-error'));
                        return false;
                    } else {
                        $(this).removeClass('error');
                    }
                }
            }
        });
        return check;
    }
    $(".submitForm").on('click', function() {
        var _this = $(this);
        var targetForm = _this.closest('form');
        var errroTarget = targetForm.find('.response');
        var check = checkRequire(targetForm, errroTarget);

        if (check == 0) {
            var formDetail = new FormData(targetForm[0]);
            formDetail.append('form_type', _this.attr('form-type'));
            $.ajax({
                method: 'post',
                url: 'ajaxmail.php',
                data: formDetail,
                cache: false,
                contentType: false,
                processData: false
            }).done(function(resp) {
                if (resp == 1) {
                    targetForm.find('input').val('');
                    targetForm.find('textarea').val('');
                    errroTarget.html('<p style="color:green;">Mail has been sent successfully.</p>');
                } else {
                    errroTarget.html('<p style="color:red;">Something went wrong please try again latter.</p>');
                }
            });
        }
    });

    var $r = null;

    var ringer = {
        
        countdown_to: $('.index3-timer').attr('data-date'),
        
        rings: {
            'DAYS': {
                s: 86400000, // mseconds in a day,
                max: 365,
                min: 0,
            },
            'HOURS': {
                s: 3600000, // mseconds per hour,
                max: 24,
                min: 0
                
            },
            'MINUTES': {
                s: 60000, // mseconds per minute
                max: 60,
                min: 0
            },
            'SECONDS': {
                s: 1000,
                max: 60,
                min: 0
            }
        },
        r_count: 5,
        r_spacing: 30, // px
        r_size: 100, // px
        r_thickness: 5, // px
        update_interval: 11, // ms


        init: function() {

            $r = ringer;
            $r.cvs = document.createElement('canvas');

            $r.size = {
                w: ($r.r_size + $r.r_thickness) * $r.r_count + ($r.r_spacing * ($r.r_count - 1)),
                h: ($r.r_size + $r.r_thickness)
            };

            $r.cvs.setAttribute('width', $r.size.w);
            $r.cvs.setAttribute('height', $r.size.h);
            $r.ctx = $r.cvs.getContext('2d');
            $(".countdownwrap").append($r.cvs);
            $r.cvs = $($r.cvs);
            $r.ctx.textAlign = 'center';
            $r.actual_size = $r.r_size + $r.r_thickness;
            $r.countdown_to_time = new Date($r.countdown_to).getTime();
            $r.cvs.css({
                width: $r.size.w + "px",
                height: $r.size.h + "px"
            });
            $r.go();
        },
        ctx: null,
        go: function() {
            var idx = 0;

            if (((new Date().getTime()) - $r.countdown_to_time) < 0)
              $r.time = (new Date().getTime()) - $r.countdown_to_time;
            else $r.time = 0;

            for (var r_key in $r.rings) $r.unit(idx++, r_key, $r.rings[r_key]);

            setTimeout($r.go, $r.update_interval);
        },
        unit: function(idx, label, ring) {
            
            var x, y, value, ring_secs = ring.s;
            value = parseFloat($r.time / ring_secs);
            $r.time -= Math.round(parseInt(value)) * ring_secs;
            value = Math.abs(value);

            x = ($r.r_size * .5 + $r.r_thickness * .5);
            x += +(idx * ($r.r_size + $r.r_spacing + $r.r_thickness));
            y = $r.r_size * .5;
            y += $r.r_thickness * .5;

            // calculate arc end angle
            var degrees = 360 - (value / ring.max) * 360.0;
            var endAngle = degrees * (Math.PI / 180);

            $r.ctx.save();

            $r.ctx.translate(x, y);
            $r.ctx.clearRect($r.actual_size * -0.5, $r.actual_size * -0.5, $r.actual_size, $r.actual_size);

            // first circle
            $r.ctx.strokeStyle = "rgb(94, 94, 107)";
            $r.ctx.beginPath();
            $r.ctx.arc(0, 0, $r.r_size / 2, 0, 2 * Math.PI, 2);
            $r.ctx.lineWidth = $r.r_thickness;
            $r.ctx.stroke();

            // second circle
            $r.ctx.strokeStyle = "rgb(255, 157, 52)";
            $r.ctx.beginPath();
            $r.ctx.arc(0, 0, $r.r_size / 2, 0, endAngle, 1);
            $r.ctx.lineWidth = $r.r_thickness;
            $r.ctx.stroke();

            // label
           // $r.ctx.fillStyle = "#222222";
            $r.ctx.fillStyle =$('.index3-timer').attr('data-color'),
            $r.ctx.font = '12px Yantramanav';
            $r.ctx.fillText(label, 0, 23);
            $r.ctx.fillText(label, 0, 23);

            $r.ctx.font = 'bold 30px Yantramanav';
            $r.ctx.fillText(Math.floor(value), 0, 5);

            $r.ctx.restore();
        }
    };

    ringer.init();
    
    /**
     * cart quantity plus minus
    */
    if (!String.prototype.getDecimals) {
        String.prototype.getDecimals = function() {
            var num = this,
                match = ('' + num).match(/(?:\.(\d+))?(?:[eE]([+-]?\d+))?$/);
            if (!match) {
                return 0;
            }
            return Math.max(0, (match[1] ? match[1].length : 0) - (match[2] ? +match[2] : 0));
        }
    }
    // Quantity "plus" and "minus" buttons
    $(document.body).on('click', '.plus, .minus', function() {
        var $qty = $(this).closest('.quantity').find('.qty'),
            currentVal = parseFloat($qty.val()),
            max = parseFloat($qty.attr('max')),
            min = parseFloat($qty.attr('min')),
            step = $qty.attr('step');

        // Format values
        if (!currentVal || currentVal === '' || currentVal === 'NaN') currentVal = 0;
        if (max === '' || max === 'NaN') max = '';
        if (min === '' || min === 'NaN') min = 0;
        if (step === 'any' || step === '' || step === undefined || parseFloat(step) === 'NaN') step = 1;

        // Change the value
        if ($(this).is('.plus')) {
            if (max && (currentVal >= max)) {
                $qty.val(max);
            } else {
                $qty.val((currentVal + parseFloat(step)).toFixed(step.getDecimals()));
            }
        } else {
            if (min && (currentVal <= min)) {
                $qty.val(min);
            } else if (currentVal > 0) {
                $qty.val((currentVal - parseFloat(step)).toFixed(step.getDecimals()));
            }
        }

        // Trigger change event
        $qty.trigger('change');
    });
    
}(jQuery));