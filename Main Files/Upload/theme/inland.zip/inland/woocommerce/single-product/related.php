<?php
/**
 * Related Products
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product/related.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see         https://docs.woocommerce.com/document/template-structure/
 * @package     WooCommerce/Templates
 * @version     3.9.0
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$inland_post_data = '';
if (function_exists('fw_get_db_post_option')):	
    $inland_post_data = fw_get_db_post_option(get_the_ID());
endif; 
$images_hover = '';
if(!empty($inland_post_data['product_hover_images']['url'])):
    $images_hover = $inland_post_data['product_hover_images']['url'];
    $images_hover_resize = inland_aq_resize($images_hover,600,600,true);
endif;
if ( $related_products ) : ?>
<section class="related products">
    <?php
	$heading = apply_filters( 'woocommerce_product_related_products_heading', __( 'Related products', 'inland' ) );
    if ($heading):
	?>
	<h2><?php echo esc_html( $heading ); ?></h2>
	<?php endif; ?>
	<div class="related-product swiper-container" >
	  <div class="swiper-wrapper">
        <?php 
          foreach ( $related_products as $related_product ) : 
			$post_object = get_post( $related_product->get_id() );
            setup_postdata( $GLOBALS['post'] =& $post_object ); 
		?>
		<div class="swiper-slide">
	    <div class="it-product-listbar it-product-style4">
	    <div class="product_item_block">
		<div class="grid-item">
			<div class="product_grid">
			<?php
			/**
			 * Hook: woocommerce_before_shop_loop_item.
			 *
			 * @hooked woocommerce_template_loop_product_link_open - 10
			 */
			do_action( 'woocommerce_before_shop_loop_item' );
			/**
			 * Hook: woocommerce_before_shop_loop_item_title.
			 *
			 * @hooked woocommerce_show_product_loop_sale_flash - 10
			 * @hooked woocommerce_template_loop_product_thumbnail - 10
			 */
			?>
			<div class="product-item">
    			<div class="inland-product-main-img">
    			<?php
    			do_action( 'woocommerce_before_shop_loop_item_title' );
    			if(!empty($images_hover_resize)):
                ?> 
                <div class="hover-product">
                <img src="<?php echo esc_url($images_hover_resize); ?>" alt="<?php the_title_attribute(); ?>" />
                </div>
                <?php endif; ?>
			  </div>
			<div class="product-ovr-links">
				<ul>
					<li>
					 <?php if($product = wc_get_product(get_the_ID())): ?> 
					   <a href="<?php echo esc_url($product->add_to_cart_url()); ?>">
						<svg xmlns="http://www.w3.org/2000/svg"
							 width="17px" height="16px">
						 <path fill-rule="evenodd"  fill="rgb(255, 255, 255)"
							 d="M16.949,4.171 L14.077,11.019 C13.972,11.258 13.752,11.410 13.501,11.410 L5.608,11.410 C5.325,11.410 5.073,11.215 5.000,10.932 L2.432,1.301 L0.629,1.301 C0.283,1.301 -0.000,1.008 -0.000,0.650 C-0.000,0.291 0.283,-0.002 0.629,-0.002 L2.903,-0.002 C3.186,-0.002 3.438,0.193 3.511,0.476 L6.079,10.107 L13.081,10.107 L15.408,4.562 L7.652,4.562 C7.306,4.562 7.023,4.269 7.023,3.910 C7.023,3.552 7.306,3.259 7.652,3.259 L16.373,3.259 C16.582,3.259 16.781,3.366 16.897,3.552 C17.012,3.737 17.033,3.964 16.949,4.171 ZM5.010,13.040 C5.796,13.040 6.436,13.704 6.436,14.519 C6.436,15.334 5.796,15.998 5.010,15.998 C4.224,15.998 3.585,15.334 3.585,14.519 C3.585,13.704 4.224,13.040 5.010,13.040 ZM13.825,13.040 C14.612,12.987 15.293,13.606 15.345,14.410 C15.366,14.813 15.251,15.192 15.000,15.486 C14.748,15.791 14.402,15.965 14.025,15.998 C13.993,15.998 13.951,15.998 13.920,15.998 C13.176,15.998 12.557,15.389 12.505,14.617 C12.452,13.813 13.039,13.095 13.825,13.040 Z"/>
						 </svg>
						</a>
					  <?php endif; ?> 
					</li>
					<?php 
            	    if( function_exists( 'yith_plugin_registration_hook' ) ) { ?>
            		<li><a href="javaScript:void(0);" class="notify-wish" data-productid="<?php echo esc_attr(get_the_ID()); ?>">
            			<?php echo do_shortcode('[yith_wcwl_add_to_wishlist]'); ?>
            		</a></li>
            		<?php } ?>
            		<li>
            		<a href="javaScript:void(0);" class = "product-pop yith-wcqv-button" data-product_id = "<?php echo get_the_id(); ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" preserveAspectRatio="xMidYMid" viewBox="0 0 15 16">
                      <path d="M14.721,14.284 L10.859,10.171 C11.619,9.059 12.028,7.707 12.014,6.331 C11.978,2.892 9.425,0.110 6.201,-0.003 C4.510,-0.045 2.939,0.605 1.750,1.873 C0.560,3.141 -0.065,4.825 -0.010,6.615 C0.095,10.051 2.706,12.771 5.934,12.809 C7.211,12.798 8.495,12.388 9.538,11.578 L13.409,15.703 C13.586,15.890 13.820,15.993 14.069,15.993 C14.339,15.993 14.596,15.868 14.774,15.650 C15.094,15.258 15.071,14.658 14.721,14.284 ZM10.145,6.501 C10.097,8.870 8.317,10.766 6.094,10.818 C4.946,10.853 3.877,10.385 3.069,9.524 C2.261,8.662 1.830,7.518 1.856,6.302 C1.905,3.933 3.684,2.037 5.906,1.985 C5.938,1.984 5.970,1.984 6.001,1.984 C7.107,1.984 8.145,2.442 8.931,3.280 C9.739,4.141 10.171,5.285 10.145,6.501 Z"/>
                    </svg>
                   </a>
                   </li>
				</ul>
			</div>
			</div>
			<?php
			/**
			 * Hook: woocommerce_shop_loop_item_title.
			 *
			 * @hooked woocommerce_template_loop_product_title - 10
			 */
			 ?>
			<div class="inland-product-infoBar">
			<?php
			do_action( 'woocommerce_shop_loop_item_title' );
			/**
			 * Hook: woocommerce_after_shop_loop_item_title.
			 *
			 * @hooked woocommerce_template_loop_rating - 5
			 * @hooked woocommerce_template_loop_price - 10
			 */
			do_action( 'woocommerce_after_shop_loop_item_title' );
		
			/**
			 * Hook: woocommerce_after_shop_loop_item.
			 *
			 * @hooked woocommerce_template_loop_product_link_close - 5
			 * @hooked woocommerce_template_loop_add_to_cart - 10
			 */
			//do_action( 'woocommerce_after_shop_loop_item' );
			?>
        	</div>
           </div>
          </div>
         </div>
         </div>
        </div>
		<?php 
        endforeach;
        wp_reset_postdata();
        ?>
      </div>
    </div>
</section>
<?php
endif;