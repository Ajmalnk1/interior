<?php
/**
 * inland woocommerce support
 */
function inland_add_woocommerce_support() {
    add_theme_support('woocommerce'); 
    add_theme_support('wc-product-gallery-lightbox');
    add_theme_support('wc-product-gallery-slider');
}
add_action('after_setup_theme', 'inland_add_woocommerce_support' );
 
/**
 *inland woocommerce remove breadcrumb
 */
 remove_action('woocommerce_before_main_content', 'woocommerce_breadcrumb', 20, 0);

/**
 * Change number or products per row to 3
 */
add_filter('loop_shop_columns', 'inland_loop_columns', 999);
if (!function_exists('inland_loop_columns')) {
	function inland_loop_columns() {
	    $inland_theme_data = '';
        if (function_exists('fw_get_db_settings_option')):	
        	$inland_theme_data = fw_get_db_settings_option();     
        endif;
        $theme_sidebar = '';
        if(!empty($inland_theme_data['wooccommerce_sidebar_position'])):
        $theme_sidebar = $inland_theme_data['wooccommerce_sidebar_position'];
        endif;
        if(! is_active_sidebar( 'woocommerce-1' )):
        	$theme_sidebar = esc_html__('full', 'inland');
        endif;
        if($theme_sidebar == 'full'):
            return 4;
        else:
            return 3;
        endif;
    }
}

/**
 * addcart remove
 */ 
remove_action('woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10, 0);
/**
 * woocommerce product title
 */ 
remove_action('woocommerce_shop_loop_item_title', 'woocommerce_template_loop_product_title', 10);  
add_action("woocommerce_shop_loop_item_title",'inland_woocommerce_template_loop_product_title'); 
function inland_woocommerce_template_loop_product_title() { 
    echo '<h2 class="woocommerce-loop-product__title"><a href="'.esc_url(get_the_permalink(get_the_ID())).'">'.get_the_title().'</a></h2>'; 
}  

/**
 * Remove "Description" Heading Title @ WooCommerce Single Product Tabs
 */
add_filter( 'woocommerce_product_description_heading', '__return_null' );
add_filter( 'woocommerce_product_additional_information_heading', '__return_null' );

/*
 * duble title 
 */
 function inland_single_product(){
$inland_theme_data = '';
if (function_exists('fw_get_db_settings_option')):	
	$inland_theme_data = fw_get_db_settings_option();
endif;
$inland_woo_breadcrumb = '';
if(!empty($inland_theme_data['breadcrumbs']['gadget'])):
    $inland_woo_breadcrumb = $inland_theme_data['breadcrumbs']['gadget'];
endif;

}
add_action('woocommerce_before_single_product_summary', 'inland_single_product' );

/**
 * all content on remove anchore link
 */ 
remove_action( 'woocommerce_before_shop_loop_item', 'woocommerce_template_loop_product_link_open', 10 );
remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_product_link_close', 5 );

add_filter( 'get_product_search_form' , 'inland_custom_product_searchform' );
function inland_custom_product_searchform( $form ) {
    $form = '<form role="search" method="get" id="searchform" action="' . esc_url( home_url( '/'  ) ) . '">
            <div>
            <input type="text" value="' . get_search_query() . '" name="s" id="ws" placeholder="' . esc_attr__( 'Search', 'inland' ) . '" />
            <button type="submit" class="search-submit">
	        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
        	 viewBox="0 0 512.005 512.005" xml:space="preserve">
            <g>
        	  <g>
        	  <path d="M505.749,475.587l-145.6-145.6c28.203-34.837,45.184-79.104,45.184-127.317c0-111.744-90.923-202.667-202.667-202.667
        			S0,90.925,0,202.669s90.923,202.667,202.667,202.667c48.213,0,92.48-16.981,127.317-45.184l145.6,145.6
        			c4.16,4.16,9.621,6.251,15.083,6.251s10.923-2.091,15.083-6.251C514.091,497.411,514.091,483.928,505.749,475.587z
        			 M202.667,362.669c-88.235,0-160-71.765-160-160s71.765-160,160-160s160,71.765,160,160S290.901,362.669,202.667,362.669z"/>
        	 </g>
          </g>
        </svg>
    	</button>
        <input type="hidden" name="post_type" value="'.esc_attr__('product','inland').'" />
    </div>
</form>';

return $form;
}

/**
 * Woocommerce rating stars always
 */ 
add_filter('woocommerce_product_get_rating_html', 'inland_get_rating_html', 10, 2);
function inland_get_rating_html($rating_html, $rating) {
  if ( $rating > 0 ) {
	$title = sprintf( __( 'Rated %s out of 5', 'inland' ), $rating );
  } else {
	$title = esc_html__('Not yet rated','inland');
	$rating = 0;
  }

  $rating_html  = '<div class="star-rating" title="' . $title . '">';
  $rating_html .= '<span style="width:' . ( ( $rating / 5 ) * 100 ) . '%"><strong class="rating">' . $rating . '</strong> ' . __( 'out of 5', 'inland' ) . '</span>';
  $rating_html .= '</div>';
  return $rating_html;
}




add_action('woocommerce_single_product_summary', 'change_single_product_ratings', 2 );
function change_single_product_ratings(){
    remove_action('woocommerce_single_product_summary','woocommerce_template_single_rating', 10 );
    add_action('woocommerce_single_product_summary','inland_single_product_ratings', 10 );
}

function inland_single_product_ratings(){
    global $product;

    $rating_count = $product->get_rating_count();

    if ( $rating_count >= 0 ) {
        $review_count = $product->get_review_count();
        $average      = $product->get_average_rating();
        $count_html   = '<div class="count-rating">' . array_sum($product->get_rating_counts()) . '</div>';
        ?>
        <div class="woocommerce-product-rating">
            <div class="container-rating"><div class="star-rating">
            <?php echo wc_get_rating_html( $average, $rating_count ); ?>
            </div>
            <?php if ( comments_open() ) : ?><a href="#reviews" class="woocommerce-review-link" rel="nofollow">(<?php printf( _n( '%s customer review', '%s customer reviews', $review_count, 'inland' ), '<span class="count">' . esc_html( $review_count ) . '</span>' ); ?>)</a><?php endif ?>
        </div></div>
        <?php
    }
}