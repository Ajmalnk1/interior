<?php
/**
 * The Template for displaying all single products
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/single-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see 	    https://docs.woocommerce.com/document/template-structure/
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     1.6.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

get_header( 'shop' );
$inland_theme_data = '';
if (function_exists('fw_get_db_settings_option')):	
	$inland_theme_data = fw_get_db_settings_option();
endif;
$theme_sidebar = '';
if(!empty($inland_theme_data['wooccommerce_single_sidebar'])):
	$theme_sidebar = $inland_theme_data['wooccommerce_single_sidebar'];
else:
	$theme_sidebar = esc_html__('single_right','inland');
endif;
if(function_exists('inland_breadcrumbs_setting')):
	inland_breadcrumbs_setting(get_the_ID());
endif;
if(! is_active_sidebar( 'woocommerce-1' )):
	$theme_sidebar = esc_html__('single_full', 'inland');
endif;
?>
<div class="content-area">
    <div class="ms-main-wrapper">
        <div class="it-product-single"> 
           <div class="container">
    		 <div class="row">
    	     <?php
    	     if($theme_sidebar == 'single_full'):
             	 echo '<div class="col-lg-12 col-md-12">';
             else:
             if($theme_sidebar == 'single_left'):
            	echo '<div class="col-lg-8 col-md-12">';
             else:
            	echo '<div class="col-lg-8 col-md-12 order-lg-1">';
             endif;
            endif;
            echo '<div class="ms-main-data">';
    		/**
    		 * woocommerce_before_main_content hook.
    		 *
    		 * @hooked woocommerce_output_content_wrapper - 10 (outputs opening divs for the content)
    		 * @hooked woocommerce_breadcrumb - 20
    		 */
    		do_action( 'woocommerce_before_main_content' );
    	   ?>
    
    		<?php while ( have_posts() ) : the_post(); ?>
    
    			<?php wc_get_template_part( 'content', 'single-product' ); ?>
    
    		<?php endwhile; // end of the loop. ?>
    
    	   <?php
    		/**
    		 * woocommerce_after_main_content hook.
    		 *
    		 * @hooked woocommerce_output_content_wrapper_end - 10 (outputs closing divs for the content)
    		 */
    		do_action( 'woocommerce_after_main_content' );
    	   ?>
        </div>
        </div>
        <?php
    	if($theme_sidebar == 'single_left'):
		  echo '<div class="col-lg-4 pull-lg-8">
			  <div class="it-blog-sidebar">
			  <aside id="secondary" class="widget-area ms-footershdow-widget">';
			  /**
        		 * woocommerce_sidebar hook.
        		 *
        		 * @hooked woocommerce_get_sidebar - 10
        		 */
			    dynamic_sidebar( 'woocommerce-1' ); 
		 echo '</aside>
		    </div>
		</div>';
		endif; 
		if($theme_sidebar == 'single_right'):
		   echo '<div class="col-lg-4 ">
			     <div class="it-blog-sidebar">
			     <aside id="secondary" class="widget-area ms-footershdow
			     -widget">';
			     /**
        		  * woocommerce_sidebar hook.
        		  *
        		  * @hooked woocommerce_get_sidebar - 10
        		  */
        		  dynamic_sidebar( 'woocommerce-1' );
		 echo '</aside>
		      </div>
		    </div>';
		endif;
	?>
	</div>
  </div>
 </div>
</div>
</div>
<?php get_footer( 'shop' );
/* Omit closing PHP tag at the end of PHP files to avoid "headers already sent" issues. */