<?php if (!defined('FW')) die('Forbidden');
$menifest = array();
$menifest['id'] = 'inland';
$menifest['supported-extensions'] = array(
	'page-builder' => array(),
	'breadcrumbs' => array(),
	'backups' => array(),
);