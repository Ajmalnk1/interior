<?php if(!defined('FW')) die('Forbidden');
$options = array(
	'infosidebar_settings' => array(
		'type' => 'tab',
		'title' => esc_html__('Info Sidebar Settings', 'inland'),
		'options' => array(
			'infosidebar' => array(
				'type'  => 'multi-picker',
				'label' => false,
				'desc'  => false,
				'value' => '',
				'picker' => array(
					'gadget' => array(
						'label'   => esc_html__('Header Info Sidebar', 'inland'),
						'type'    => 'switch',
						'left-choice' => array(
							'value' => 'off',
							'label' => esc_html__('Off', 'inland'),
						),
						'right-choice' => array(
							'value' => 'on',
							'label' => esc_html__('On', 'inland'),
						),
					),
			    ),
				'choices' => array(
					'on' => array(
					'social_icon' => array(
						'label'   => esc_html__('Social Icon', 'inland'),
						'type'    => 'switch',
						'left-choice' => array(
							'value' => 'off',
							'label' => esc_html__('Off', 'inland')
						    ),
						'right-choice' => array(
							'value' => 'on',
							'label' => esc_html__('On', 'inland')
						    ),
				        ),
					'phon' => array(
							'label' => esc_html__('Phon Number', 'inland'),
							'type'  => 'text',
							'value' => '',
						),
					'email' => array(
						'label' => esc_html__('Email Id', 'inland'),
						'type'  => 'text',
						'value' => '',
					    ),
					),
				),
			),
	    )
	)
);