<?php if(!defined ('FW')) die('Forbidden');
$options = array(
    fw()->theme->get_options('customizer/inland-general-settings'),
	fw()->theme->get_options('customizer/inland-header-settings'),
	fw()->theme->get_options( 'customizer/inland-infosidebar-settings'),
	fw()->theme->get_options('customizer/inland-breadcrumbs-settings'),
	fw()->theme->get_options('customizer/inland-sidebar-settings'),
	fw()->theme->get_options('customizer/inland-login-signup-settings'),
	fw()->theme->get_options('customizer/inland-woocommerce-sidebar-settings'),
	fw()->theme->get_options( 'customizer/inland-404-settings'),
	fw()->theme->get_options( 'customizer/inland-social-settings'),
	fw()->theme->get_options( 'customizer/inland-footer-settings'),
	fw()->theme->get_options( 'customizer/inland-singlepage-settings'),
);