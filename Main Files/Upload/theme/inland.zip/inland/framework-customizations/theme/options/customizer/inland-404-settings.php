<?php if(!defined ('FW')) die('Forbidden');
$options = array(
	'error_404_settings' => array(
	'type' => 'tab',
	'title' => esc_html__('404 Settings', 'inland'),
	'options' => array(
            'err_title' => array(
				'label' => esc_html__('404 Title', 'inland'),
				'type' => 'text',
			),
			'error_404_desc'  => array( 
				'label' => esc_html__('404 Description', 'inland'),
				'type' => 'wp-editor',
				'media_buttons' => false,
				'wpautop' => false, 
		 	),
			'emptypageimage' => array(
				'label' => esc_html__('404 Image', 'inland'),
				'type' => 'upload',
			), 
		)
    ) 
);