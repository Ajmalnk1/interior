<?php if(!defined('FW')) die('Forbidden');
$options = array(
	'social_settings' => array(
	'type' => 'tab',
	'title' => esc_html__('Social Settings', 'inland'),
	'options' => array(
		'facebook_url' => array(
			'label' => esc_html__('Facebook Button', 'inland'),
			'type' => 'text',
			'desc' => esc_html__('Enter Facebook Url', 'inland'),
			),
		'insta_url' => array(
			'label' => esc_html__('Instagram Button', 'inland'),
			'type' => 'text',
			'desc' => esc_html__('Enter Instagram Url', 'inland'),
			),
		'twitter_url' => array(
			'label' => esc_html__('Twitter Button', 'inland'),
			'type' => 'text',
			'desc' => esc_html__('Enter Twitter Url', 'inland'),
			),
		'behance_url' => array(
			'label' => esc_html__('Behance Button', 'inland'),
			'type' => 'text',
			'desc' => esc_html__('Enter Behance Url', 'inland'),
			),
		'dribbble_url' => array(
			'label' => esc_html__('Dribbble Button', 'inland'),
			'type' => 'text',
			'desc' => esc_html__('Enter Dribbble Url', 'inland'),
			),
		'pinterest_url' => array(
			'label' => esc_html__('Pinterest Button', 'inland'),
			'type' => 'text',
			'desc' => esc_html__('Enter Pinterest Url', 'inland'),
			),
		'youtube_url' => array(
			'label' => esc_html__('Youtube Button', 'inland'),
			'type' => 'text',
			'desc' => esc_html__('Enter Youtube Url', 'inland'),
			),
		),
	),
);