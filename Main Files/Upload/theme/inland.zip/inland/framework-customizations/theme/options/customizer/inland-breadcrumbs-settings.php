<?php if(!defined('FW')) die ('Forbidden');
$options = array(
	'breadcrumbs_settings' => array(
	'type' => 'tab',
	'title' => esc_html__('Breadcrumbs Settings', 'inland'),
	'options' => array(
			'breadcrumbs' => array(
				'type'  => 'multi-picker',
				'label' => false,
				'desc'  => false,
				'value' => 'on',
				'picker' => array(
					'gadget' => array(
						'label'   => esc_html__('Breadcrumbs Enable/Disable', 'inland'),
						'type'    => 'switch',
						'value' => 'on',
						'left-choice' => array(
							'value' => 'off',
							'label' => esc_html__('Off', 'inland'),
						),
						'right-choice' => array(
							'value' => 'on',
							'label' => esc_html__('On', 'inland'),
						),
					),
				),
				'choices' => array(
				'on' => array(
				'breadcrubs_img' => array(
							'label' => esc_html__('Breadcrumbs Background Image', 'inland'),
							'type' => 'upload',
							'desc' => esc_html__('Breadcrumbs Background Upload image Here.', 'inland'),
					    ),
				    ),
			    ),
			),
		),
	),
);