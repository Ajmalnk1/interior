<?php if(!defined ('FW')) die('Forbidden');
$options = array(
	'sidebar_settings' => array(
	'type' => 'tab',
	'title' => esc_html__('Sidebar Settings', 'inland'),
	'options' => array(
			'sidebar_position' => array(
				'label' => esc_html__('Blog Sidebar Position', 'inland'),
				'type' => 'image-picker',
				'value'   => 'left',
				'desc' => esc_html__('Select main content and sidebar alignment. Choose between 1, 2 or 3 column layout.', 'inland'),
				'choices' => array(
					'full' => array(
						'small' => array(
							'src' => get_template_directory_uri() .'/assets/images/1c.png',
							'height' => 40
						),
					),
					'left' => array(
						'small' => array(
							'src' => get_template_directory_uri() .'/assets/images/2cl.png',
							'height' => 40
						),
					),
					'right' => array(
						'small' => array(
							'src' => get_template_directory_uri() .'/assets/images/2cr.png',
							'height' => 40
						),
					),
				),
			),
		)
	)
);