<?php if(!defined('FW')) die('Forbidden');
$options = array(
	'footer_settings' => array(
		'type' => 'tab',
		'title' => esc_html__('Footer Settings', 'inland'),
		'options' => array(
			'footer_option' => array(
				'type'  => 'multi-picker',
				'label' => false,
				'picker' => array(
					'gadget' => array(
						'label'   => esc_html__('Footer', 'inland'),
						'type'    => 'switch',
						'left-choice' => array(
							'value' => 'off',
							'label' => esc_html__('Off', 'inland'),
						),
						'right-choice' => array(
							'value' => 'on',
							'label' => esc_html__('On', 'inland'),
						),
					),
				),
			),
			'copyright_text' => array(
				'label' => esc_html__('Copyright Text', 'inland'),
				'type' => 'textarea',
				'desc' => esc_html__('Enter Copyright Text Here.', 'inland'),
			),
		),
	),
);