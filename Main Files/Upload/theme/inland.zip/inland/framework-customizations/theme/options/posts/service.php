<?php if( !defined('FW') ) die('Forbidden');
$options = array(
    'main' => array(
        'type' => 'box',
        'title' => esc_html__('Service Options', 'inland'),
        'options' => array(
            'subheading'  => array(  
                'type' => 'text',
                'label'   => esc_html__('Subheading', 'inland'),
           ),    	
        ), 
    ),
);
?>