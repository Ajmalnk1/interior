<?php if(!defined('FW')) die('Forbidden');
$options = array(
	'singlepage_settings' => array(
		'type' => 'tab',
		'title' => esc_html__('Single Page Settings', 'inland'),
		'options' => array(
			'home_pages' =>	array(
					'type'  => 'multi-select',
					'label' => esc_html__('Add Pages', 'inland'),
					'population' => 'array',
					'choices' => inland_list_all_pages(),
					'desc'  => esc_html__('Add Pages For Single Page Website', 'inland'),
					'help'  => __('Tis Page will show as a home page section.', 'inland'),
				),
	    )
	)
);