<?php if(!defined ('FW')) die('Forbidden');
$options = array(
	'general_settings' => array(
	'type' => 'tab',
	'title' => esc_html__( 'General Settings', 'inland' ),
	'options' => array(
			'logo' => array(
				'type'  => 'multi-picker',
				'label' => false,
				'desc'  => false,
				'value' => '',
				'picker' => array(
					'gadget' => array(
						'label'   => esc_html__('Choose Logo', 'inland'),
						'type'    => 'switch',
						'left-choice' => array(
							'value' => 'logoimge',
							'label' => esc_html__('logoimge', 'inland')
						),
						'right-choice' => array(
							'value' => 'logosvg',
							'label' => esc_html__('logosvg', 'inland')
						),
					),
				),
				 'choices' => array(
					 'logoimge' => array(
						'logoimge_clone' => array(
						 'label' => esc_html__('Logo Image', 'inland'),
						 'type' => 'upload',
						),
					 ),
					 'logosvg' => array(
					 'logosvg_clone' => array(
					 'label' => esc_html__('Logo Svg Code', 'inland'),
					 'type' => 'textarea',
					 'desc' => esc_html__('Enter svg code', 'inland'),
					 ),
					),
				 ),
			 ),	
	        'demoimport' => array(
			    'type'  => 'switch',
		        'value' => 'Off',
		        'label' => esc_html__('Demo Live Class', 'inland'),
			        'left-choice' => array(
						'value' => 'off',
						'label' => esc_html__('Off', 'inland'),
					    ),
			        'right-choice' => array(
						  'value' => 'on',
						  'label' => esc_html__('On', 'inland'),
					     ),
		        ),
		   'demo-color' => array(
                'type'  => 'select',
                'value' => 'choice1',
                'label' => esc_html__('Demo Color', 'inland'),
                'choices' => array(
                    '1' => esc_html__('Demo 1', 'inland'),
                    '2' => esc_html__('Demo 2', 'inland'),
                    '3' => esc_html__('Demo 3', 'inland'),
                    '4' => esc_html__('Demo 4', 'inland'),
                    '5' => esc_html__('Demo 5', 'inland'),
                ),
                'no-validate' => false,
            ),
			
		  'loader' => array(
				'type'  => 'multi-picker',
			    'picker' => array(
					'gadget' => array(
						'type'  => 'switch',
						'value' => 'on',
						'label' => esc_html__('Loader Enable/Disable', 'inland'),
							'left-choice' => array(
								'value' => 'off',
								'label' => esc_html__('Off', 'inland'),
								),
							'right-choice' => array(
								  'value' => 'on',
								  'label' => esc_html__('On', 'inland'),
					  			),
						)
				),
				'choices' => array(
					'on' => array(
						'loader_image'  => array(
							 'label' => esc_html__('Loader Image', 'inland'),
							 'desc' => esc_html__('Upload loader image Here.', 'inland'),
							 'type' => 'upload', 
						 ),
					),
			    ),
			),
			'rtl_mode' => array(
			    'type'  => 'switch',
		        'value' => 'Off',
		        'label' => esc_html__('RTL Mode', 'inland'),
			        'left-choice' => array(
						'value' => 'off',
						'label' => esc_html__('Off', 'inland'),
					    ),
			        'right-choice' => array(
						  'value' => 'on',
						  'label' => esc_html__('On', 'inland'),
					     ),
		        ),
		),
	),
);