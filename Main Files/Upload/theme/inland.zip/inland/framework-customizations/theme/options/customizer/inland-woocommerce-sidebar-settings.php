<?php if(!defined ('FW')) die('Forbidden');
$options = array(
	'wooccommerce_sidebar_settings' => array(
	'type' => 'tab',
	'title' => esc_html__('WooCommerce Settings', 'inland'),
	'options' => array(
			'wooccommerce_sidebar_position' => array(
				'label' => esc_html__('WooCommerce Shop Sidebar', 'inland'),
				'type' => 'image-picker',
				'value'   => 'left',
				'desc' => esc_html__('Select main content and sidebar alignment. Choose between 1, 2 or 3 column layout.', 'inland'),
				'choices' => array(
					'full' => array(
						'small' => array(
							'src' => get_template_directory_uri() .'/assets/images/1c.png',
							'height' => 40
						),
					),
					'right' => array(
						'small' => array(
							'src' => get_template_directory_uri() .'/assets/images/2cl.png',
							'height' => 40
						),
					),
					'left' => array(
						'small' => array(
							'src' => get_template_directory_uri() .'/assets/images/2cr.png',
							'height' => 40
						),
					),
				),
			),
			'wooccommerce_single_sidebar' => array(
				'label' => esc_html__('WooCommerce Single Sidebar', 'inland'),
				'type' => 'image-picker',
				'value'   => 'left',
				'desc' => esc_html__('Select main content and sidebar alignment. Choose between 1, 2 or 3 column layout.', 'inland'),
				'choices' => array(
					'single_full' => array(
						'small' => array(
							'src' => get_template_directory_uri() .'/assets/images/1c.png',
							'height' => 40
						),
					),
					'single_right' => array(
						'small' => array(
							'src' => get_template_directory_uri() .'/assets/images/2cl.png',
							'height' => 40
						),
					),
					'single_left' => array(
						'small' => array(
							'src' => get_template_directory_uri() .'/assets/images/2cr.png',
							'height' => 40
						),
					),
				),
			),
		)
	)
);