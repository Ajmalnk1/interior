<?php if(!defined('FW')) die('Forbidden');
$options = array(
	'header_settings' => array(
		'type' => 'tab',
		'title' => esc_html__('Header Settings', 'inland'),
		'options' => array(
			'headerbg' => array(
				'type'  => 'multi-picker',
				'label' => false,
				'desc'  => false,
				'value' => '',
				'picker' => array(
					'gadget' => array(
						'label'   => esc_html__('Header Background Color', 'inland'),
						'type'    => 'switch',
						'left-choice' => array(
							'value' => 'off',
							'label' => esc_html__('Off', 'inland'),
						),
						'right-choice' => array(
							'value' => 'on',
							'label' => esc_html__('On', 'inland'),
						),
					),
			    ),
				'choices' => array(
					'on' => array(
					'header_bg_clr' => array(
							'label' => esc_html__('Header Background Color', 'inland'),
							'type'  => 'color-picker',
							'value' => '#000000',
						),
					),
				),
			),
			'select-header' => array(
				'type'    => 'select',
				'label'   => esc_html__('Select Header', 'inland'),
				'choices' => array(
					'header-main'  => esc_html__('Header 1', 'inland'),
					'header-1' => esc_html__('Header 2', 'inland')
				),
			),
			'mincart' => array(
				'label' => esc_html__('Cart Icon', 'inland'),
				'type' => 'switch',
				'left-choice' => array(
					'value' => 'off',
					'label' => esc_html__('Off', 'inland'),
				),
				'right-choice' => array(
					'value' => 'on',
					'label' => esc_html__('On', 'inland'),
				),
			),
			'search' => array(
				'label' => esc_html__('Search Icon', 'inland'),
				'type' => 'switch',
				'left-choice' => array(
					'value' => 'off',
					'label' => esc_html__('Off', 'inland'),
				),
				'right-choice' => array(
					'value' => 'on',
					'label' => esc_html__('On', 'inland'),
				),
			),
			'login' => array(
				'label' => esc_html__('Login/Registration Icon', 'inland'),
				'type' => 'switch',
				'left-choice' => array(
					'value' => 'off',
					'label' => esc_html__('Off', 'inland'),
				),
				'right-choice' => array(
					'value' => 'on',
					'label' => esc_html__('On', 'inland'),
				),
			),
			'profile_pages' =>array(
				   'type' => 'addable-popup',
				   'value' => array(
							 array(
							   'profile_pages' => 'Page Setting',
							   ),
							),
					'label' => esc_html__('Add Page Setting', 'inland'),
					'template' => esc_html__('Add Page Setting','inland'),
					'popup-title' => null,
					'size' => 'small', // small, medium, large
					'limit' => 0, // limit the number of popup`s that can be added
					'add-button-text' => esc_html__('Add', 'inland'), 
					'sortable' => true,
					'popup-options' => array(
						'title' => array(
						   'label' => esc_html__('Page title', 'inland'),
						   'type' => 'text', 
							),
						'user_profile_page'  => array( 
							'label' => esc_html__('Profile Page', 'inland'),
							'type' => 'select',
							'value' => '',
							'desc'  => esc_html__('user profile page', 'inland'),
							'choices' => inland_list_all_pages(),
							),  
						), 
			   ), 
	    )
	)
);