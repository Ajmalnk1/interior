<?php if(!defined('FW')) die('Forbidden');
$options = array(
	'main' => array(
		'type' => 'box',
		'title' => esc_html__('Product Options', 'inland'),
		'options' => array(
		    
		    'product_hover_images' => array(
				'type'  => 'upload',
				'images_only' => true,
				'label' => esc_html__('Upload Product Hover Image', 'inland'),
			),    
		),
	),
);
?>