<?php if(!defined('FW')) die('Forbidden');
$options = array(
	'main' => array(
		'type' => 'box',
		'title' => esc_html__('Post Options', 'inland'),
		'options' => array(
			'post_sidebar' => array(
				'label' => esc_html__('Post Sidebar Position', 'inland'),
				'type' => 'image-picker',
				'value' => 'right',
				'desc' => esc_html__('Select main content and sidebar alignment. Choose between 1, 2 or 3 column layout.', 'inland'),
				'choices' => array(
					'full' => array(
                        'small' => array(
                            'height' => 50,
                            'src'    => get_template_directory_uri() . '/assets/images/1c.png'
                        ),
                    ),
                    'left' => array(
                        'small' => array(
                            'height' => 50,
                            'src'    => get_template_directory_uri() . '/assets/images/2cl.png'
                        ),
                    ),
                    'right' => array(
                        'small' => array(
                            'height' => 50,
                            'src'    => get_template_directory_uri() . '/assets/images/2cr.png'
                        ),
                    ),
				),
			),
			'post_breadcrumbs_switch' => array(
				'type' => 'switch',
				'value' => 'on',
                'label' => esc_html__('Breadcrumbs Enable/Disable', 'inland'),
                    'left-choice' => array(
                        'value' => 'off',
                        'label' => esc_html__('Off', 'inland'),
                    ),
                    'right-choice' => array(
                        'value' => 'on',
                        'label' => esc_html__('On', 'inland'),
                    ),
			),
			'authorinfo_switch' => array(
				'type' => 'multi-picker',
				'label' => false,
    			'desc'  => false,
				'picker' => array(
					'author_switch' => array(
						'type' => 'switch',
						'value' => 'off',
						'label' => esc_html__('Author Information Enable/Disable', 'inland'),
                        'left-choice' => array(
                                'value' => 'off',
                                'label' => esc_html__('Off', 'inland'),
                                ),
                        'right-choice' => array(
                                'value' => 'on',
                                'label' => esc_html__('On', 'inland'),
                               ),
                        ),					
					),
				'choices' => array(
					'on' => array(
						'author_names' => array(
							'type'  => 'text',
							'label' => esc_html__('Enter Author Name', 'inland'),
						), 
						'author_images' => array(
							'type'  => 'upload',
							'images_only' => true,
							'label' => esc_html__('Enter Author Image', 'inland'),
						),        
						'author_summery' => array(
							'type'  => 'textarea',
							'label' => esc_html__('Enter Author About', 'inland'),
						), 
						'author_facebook' => array(
							'type'  => 'text',
							'label' => esc_html__('Enter Author facebook page url', 'inland'),
						), 
						'author_insta' => array(
							'type'  => 'text',
							'label' => esc_html__('Enter Author youtube page url', 'inland'),
						),       
						'author_twitter' => array(
							'type'  => 'text',
							'label' => esc_html__('Enter Author twitter page url', 'inland'),
						),
						'author_behance' => array(
							'type'  => 'text',
							'label' => esc_html__('Enter Author behance page url', 'inland'),
						),
						'author_dribbble' => array(
							'type'  => 'text',
							'label' => esc_html__('Enter Author dribbble page url', 'inland'),
						),
						'author_pinterest' => array(
							'type'  => 'text',
							'label' => esc_html__('Enter Author pinterest page url', 'inland'),
						),  
					), 
			    ),				
			),
		),
	),
);
?>