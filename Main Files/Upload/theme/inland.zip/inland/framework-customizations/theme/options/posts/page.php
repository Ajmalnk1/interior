<?php if(!defined('FW')) die('Forbidden');
$options = array(
	'main' => array(
		'type' => 'box',
		'title' => esc_html__('Page Options', 'inland'),
		'options' => array(
			'page_sidebar' => array(
				'label' => esc_html__('Page Sidebar Position', 'inland'),
				'type' => 'image-picker',
				'value' => 'right',
				'desc'    => esc_html__('Select main content and sidebar alignment. Choose between 1, 2 or 3 column layout.',
                    'inland' ),
				'choices' => array(
                    'full' => array(
                        'small' => array(
                            'height' => 50,
                            'src'    => get_template_directory_uri() . '/assets/images/1c.png'
                        ),
                    ),
                    'left' => array(
                        'small' => array(
                            'height' => 50,
                            'src'    => get_template_directory_uri() . '/assets/images/2cl.png'
                        ),
                    ),
                    'right' => array(
                        'small' => array(
                            'height' => 50,
                            'src'    => get_template_directory_uri() . '/assets/images/2cr.png'
                        ),
                    ),
                ),
			),
			'page_breadcrumbs_switch' => array(
                'type'  => 'switch',
                'value' => 'on',
                'label' => esc_html__('Breadcrumbs Enable/Disable', 'inland'),
                    'left-choice' => array(
                        'value' => 'off',
                        'label' => esc_html__('Off', 'inland'),
                    ),
    				'right-choice' => array(
    					'value' => 'on',
    					'label' => esc_html__('On', 'inland'),
				    ),
            ),          
		),
	),
);