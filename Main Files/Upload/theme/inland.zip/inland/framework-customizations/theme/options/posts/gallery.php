<?php if( !defined('FW') ) die('Forbidden');
$options = array(
    'main' => array(
        'type' => 'box',
        'title' => esc_html__('Gallery Options', 'inland'),
        'options' => array(
            'bottom_heading'  => array(  
				 'type' => 'text',
				 'label'   => esc_html__('Bottom Heading', 'inland'),
            ), 
            'bottom_subheading'  => array(  
                'type' => 'text',
                'label'   => esc_html__('Bottom Subheading', 'inland'),
           ),
           'col_class'  => array(  
            'type' => 'select',
            'label'   => esc_html__('Image Style', 'inland'),
            'choices' => array(
                'style_one' => esc_html__('Style One', 'inland'),
                'style_two' => esc_html__('Style Two', 'inland'),
                ),
            ),      	
        ), 
    ),
);