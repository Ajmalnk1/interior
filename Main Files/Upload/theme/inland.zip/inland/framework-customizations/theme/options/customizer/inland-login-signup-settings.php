<?php if(!defined ('FW')) die('Forbidden');
$options = array(
	'login_signup_settings' => array(
		'type' => 'tab',
		'title' => esc_html__('Login/Signup Settings', 'inland'),
		'options' => array(
		    'woo_logo' => array(
				'type'  => 'multi-picker',
				'label' => false,
				'desc'  => false,
				'value' => '',
				'picker' => array(
					'gadget' => array(
						'label'   => esc_html__('Choose Logo', 'inland'),
						'type'    => 'switch',
						'left-choice' => array(
							'value' => 'logoimge',
							'label' => esc_html__('logoimge', 'inland')
						),
						'right-choice' => array(
							'value' => 'logosvg',
							'label' => esc_html__('logosvg', 'inland')
						),
					),
				),
				 'choices' => array(
					 'logoimge' => array(
						'logoimge_clone' => array(
						 'label' => esc_html__('Logo Image', 'inland'),
						 'type' => 'upload',
						),
					 ),
					 'logosvg' => array(
					 'logosvg_clone' => array(
					 'label' => esc_html__('Logo Svg Code', 'inland'),
					 'type' => 'textarea',
					 'desc' => esc_html__('Enter svg code', 'inland'),
					 ),
					),
				 ),
			 ),	
			'woocommerce_btn' => array(
				'label' => esc_html__('WooCommerce Slider On/Off', 'inland'),
				'type' => 'switch',
				'left-choice' => array( 
					'value' => 'off',
					'label' => esc_html__('Off', 'inland'),
				),
    			'right-choice' => array(
    					'value' => 'on',
    					'label' => esc_html__('On', 'inland'),
    				),
		      ),
			'login_title' => array(
				'label' => esc_html__('Login Form Title', 'inland'),
				'type'  => 'text',
				'desc' => esc_html__('Enter Login title here.', 'inland'),
			),
			'login_desc' => array(
				'label' => esc_html__('Login Description', 'inland'),
				'type'  => 'textarea',
				'desc' => esc_html__('Enter Login description here.', 'inland'),
		    ),
			'signup_title' => array(
				'label' => esc_html__('Signup Form Title', 'inland'),
				'type'  => 'text',
				'desc' => esc_html__('Enter Signup title here.', 'inland'),
			),
			'signup_desc' => array(
				'label' => esc_html__('Signup Description', 'inland'),
				'type'  => 'textarea',
				'desc' => esc_html__('Enter Signup description here.', 'inland'),
		    ),
			
		),
	)
);