<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package inland
 */
get_header();
?>
<div id="primary" class="content-area"> 
	<main id="main" class="site-main">
	<?php
	/**
	 * inland 404 content area
	 */
	$inland_setting = ''; 
	if(class_exists('Inland_themesetting')):
		$inland_setting = new Inland_themesetting();
		$inland_setting->inland_404_setting(get_the_ID());
	endif;
	?>
	</main><!-- #main -->
</div><!-- #primary -->
<?php
get_footer();