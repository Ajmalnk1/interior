<?php
/***
 * Template Name: Inland Blog
 *  
 * inland Blog Template
 * @package inland
 */ 
get_header();
$inland_theme_data = '';
if (function_exists('fw_get_db_post_option')):	
    $inland_theme_data = fw_get_db_post_option(get_the_ID());
endif; 

if (function_exists('fw_get_db_settings_option')):	
    $inland_meta_data = fw_get_db_settings_option();
endif; 
if(function_exists('inland_breadcrumbs_setting')):
     inland_breadcrumbs_setting(get_the_ID());
endif;  
echo '<div class="it-blog-category"> 
        <div class="container">
          <div class="row">';
    	   $theme_sidebar = '';
    	   if(!empty($inland_meta_data['sidebar_position'])):
        	    $theme_sidebar = $inland_meta_data['sidebar_position'];
           else:
    		    $theme_sidebar = esc_html__('right','inland');
    	   endif;
    	   if(! is_active_sidebar( 'sidebar-1' )):
                $theme_sidebar = esc_html__('full','inland');     
           endif; 
    	   if($theme_sidebar == 'full'):
    			echo '<div class="col-lg-12 col-md-12">';
         else:
    		    if($theme_sidebar == 'left'):
    				echo '<div class="col-lg-8 col-md-12 order-lg-2">';
    			else:
    				echo '<div class="col-lg-8 col-md-12">';
    			endif;
         endif;
        	$paged = (get_query_var( 'paged' )) ? get_query_var('paged') : 1;
  		    $args = array(
                     'post_type' =>'post',
          			 'paged' => $paged,
          			 'post_status' =>'publish',
                    );
            $inland_query = new WP_Query($args);
	        if($inland_query->have_posts()) :
    		   while ($inland_query->have_posts()) : $inland_query->the_post();
    	    ?>
            <div class="it-blog-post">
                <?php if(has_post_thumbnail()): ?>
                <div class="it-blog-content-image">
                <a class="post-thumbnail" href="<?php the_permalink(); ?>" aria-hidden="true" tabindex="-1">
            	<?php
            	  the_post_thumbnail( 'post-thumbnail', array(
            	    	'alt' => the_title_attribute( array(
            			'echo' => false,
            	    	) ),
                	) );
            	?>
                </a> 
                <span class="land-blog-date">
                   <span><?php echo get_the_date( '<b>j</b> M' ); ?></span>
                </span> 
                </div>
                <?php endif; ?>
            <div class="it-blog-user">
                <ul>
                  <?php if(!has_post_thumbnail()): ?>  
                  <li>
                    <a href="<?php echo esc_url(get_permalink()); ?>">
                      <i class="far fa-calendar-alt"></i>
                       <span><?php echo get_the_date(); ?></span>
                    </a>
                  </li>
                  <?php endif; ?>
                   <li>
                    <a href="<?php echo esc_url(get_comments_link(get_the_ID())); ?>">
                        <span class="blog-icons">
                        <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" preserveAspectRatio="xMidYMid" viewBox="0 0 19 15">
                          <path d="M18.247,10.573 C17.745,11.316 17.056,11.943 16.180,12.454 C16.251,12.625 16.323,12.781 16.397,12.923 C16.472,13.065 16.560,13.202 16.662,13.333 C16.765,13.465 16.844,13.568 16.901,13.642 C16.957,13.717 17.049,13.821 17.176,13.956 C17.303,14.091 17.385,14.180 17.420,14.222 C17.427,14.229 17.441,14.245 17.462,14.270 C17.484,14.295 17.500,14.313 17.510,14.323 C17.521,14.334 17.535,14.352 17.553,14.377 C17.570,14.401 17.582,14.421 17.590,14.435 L17.616,14.488 C17.616,14.488 17.623,14.510 17.638,14.552 C17.651,14.595 17.653,14.618 17.643,14.621 C17.632,14.625 17.629,14.648 17.632,14.690 C17.611,14.790 17.565,14.868 17.494,14.925 C17.424,14.981 17.346,15.006 17.261,14.999 C16.908,14.950 16.603,14.893 16.349,14.829 C15.260,14.545 14.278,14.090 13.402,13.466 C12.765,13.579 12.144,13.636 11.536,13.636 C9.620,13.636 7.952,13.167 6.531,12.230 C6.941,12.258 7.252,12.272 7.464,12.272 C8.602,12.272 9.694,12.113 10.740,11.793 C11.786,11.474 12.719,11.015 13.539,10.419 C14.423,9.766 15.102,9.013 15.575,8.161 C16.049,7.309 16.286,6.407 16.286,5.456 C16.286,4.908 16.204,4.369 16.042,3.836 C16.953,4.340 17.674,4.972 18.204,5.732 C18.734,6.492 18.999,7.309 18.999,8.182 C18.999,9.035 18.749,9.831 18.247,10.573 ZM11.212,10.179 C10.064,10.666 8.814,10.909 7.465,10.909 C6.856,10.909 6.234,10.852 5.598,10.738 C4.722,11.364 3.739,11.818 2.650,12.102 C2.396,12.166 2.092,12.222 1.739,12.272 L1.707,12.272 C1.629,12.272 1.557,12.244 1.489,12.187 C1.423,12.130 1.382,12.056 1.367,11.964 C1.361,11.942 1.357,11.919 1.357,11.894 C1.357,11.870 1.359,11.846 1.362,11.825 C1.366,11.804 1.373,11.783 1.383,11.761 L1.410,11.709 C1.410,11.709 1.423,11.689 1.447,11.649 C1.472,11.611 1.486,11.593 1.489,11.597 C1.493,11.600 1.509,11.582 1.538,11.543 C1.566,11.504 1.580,11.488 1.580,11.495 C1.615,11.452 1.697,11.364 1.824,11.229 C1.951,11.094 2.043,10.990 2.099,10.915 C2.156,10.840 2.236,10.738 2.338,10.606 C2.441,10.475 2.529,10.338 2.603,10.196 C2.677,10.054 2.749,9.898 2.821,9.727 C1.944,9.216 1.255,8.587 0.753,7.842 C0.251,7.096 0.000,6.301 0.000,5.456 C0.000,4.469 0.332,3.556 0.997,2.718 C1.661,1.881 2.568,1.218 3.716,0.732 C4.865,0.245 6.114,0.002 7.465,0.002 C8.815,0.002 10.064,0.245 11.212,0.732 C12.361,1.218 13.267,1.880 13.932,2.718 C14.596,3.556 14.928,4.469 14.928,5.456 C14.928,6.442 14.596,7.355 13.932,8.193 C13.267,9.031 12.361,9.693 11.212,10.179 ZM12.739,3.421 C12.184,2.789 11.437,2.289 10.497,1.919 C9.556,1.550 8.546,1.366 7.465,1.366 C6.383,1.366 5.372,1.550 4.432,1.919 C3.492,2.289 2.744,2.789 2.190,3.421 C1.635,4.053 1.357,4.731 1.357,5.456 C1.357,6.038 1.545,6.599 1.919,7.139 C2.294,7.678 2.820,8.147 3.499,8.545 L4.528,9.141 L4.156,10.036 C4.397,9.894 4.616,9.755 4.814,9.620 L5.281,9.290 L5.842,9.397 C6.394,9.496 6.935,9.545 7.465,9.545 C8.546,9.545 9.556,9.361 10.497,8.992 C11.437,8.623 12.184,8.122 12.739,7.490 C13.294,6.858 13.572,6.180 13.572,5.456 C13.572,4.731 13.294,4.053 12.739,3.421 Z"></path>
                        </svg>
                        </span>
                        <span>
                        <?php    
                        if(get_comments_number(get_the_ID()) == "1"){
    					     echo get_comments_number(get_the_ID()); 
    					     esc_html_e(' Comment','inland'); 
    					 }else{
    					    echo get_comments_number(get_the_ID()); 
    					    esc_html_e(' Comments','inland'); 
    					 }    
                        ?>
                       </span>
                    </a>
                </li>
                <li>
                <a href="<?php echo esc_url(get_author_posts_url(get_the_ID())); ?>">
                    <span class="blog-icons">
                    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" preserveAspectRatio="xMidYMid" viewBox="0 0 15 15">
                      <path d="M12.821,9.696 C12.001,8.879 11.026,8.274 9.962,7.908 C11.114,7.117 11.867,5.787 11.850,4.286 C11.823,1.899 9.838,-0.032 7.443,-0.001 C5.071,0.030 3.151,1.963 3.151,4.335 C3.151,5.816 3.899,7.126 5.039,7.908 C3.975,8.274 3.000,8.879 2.180,9.696 C0.910,10.962 0.150,12.600 0.003,14.363 C-0.026,14.705 0.242,15.000 0.586,15.000 L0.591,15.000 C0.897,15.000 1.149,14.764 1.175,14.460 C1.450,11.222 4.182,8.671 7.500,8.671 C10.819,8.671 13.550,11.222 13.826,14.460 C13.852,14.764 14.104,15.000 14.410,15.000 L14.414,15.000 C14.758,15.000 15.027,14.705 14.998,14.363 C14.850,12.600 14.090,10.962 12.821,9.696 ZM4.328,4.440 C4.268,2.613 5.772,1.113 7.606,1.173 C9.269,1.227 10.619,2.572 10.673,4.230 C10.732,6.058 9.228,7.557 7.395,7.498 C5.732,7.444 4.382,6.098 4.328,4.440 Z"></path>
                    </svg>
                    </span>
                    <span><?php the_author(); ?></span>
                    </a>
                </li>
                </ul>
              </div>
             <?php
              if(is_singular() ) :
                the_title( '<h2 class="entry-title it-blogTitle"><a href="' . esc_url( get_permalink() ) . '" rel="'.esc_attr__('bookmark','inland').'">', '</a></h2>' );
              else : 
              the_title( '<h2 class="entry-title it-blogTitle"><a href="' . esc_url( get_permalink() ) . '" rel="'.esc_attr__('bookmark','inland').'">', '</a></h2>' ); 
              endif;
            ?>
        	<div class="entry-content">
                <p>
                <?php
                inland_the_excerpt(350);
                wp_link_pages( array(
                		'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'inland' ),
                		'after'  => '</div>',
                	) );
                ?>
                </p>
            <a href="<?php echo esc_url(get_the_permalink(get_the_ID())); ?>" class="it-btn">
             <?php esc_html_e('Read More','inland'); ?> 
             <span class="btn-caret"><i class="fas fa-caret-right"></i></span>
            </a>
            </div><!-- .entry-content -->
            </div>	
            <?php
            endwhile;
            echo '<div class="blog-pagination-section">';
                  $GLOBALS['wp_query']->max_num_pages = $inland_query->max_num_pages;
                  inland_blogtemp_pagination();	
                  wp_reset_postdata();
            echo '</div>'; 
            else :
                get_template_part( 'template-parts/content', 'none' );
            endif;
            echo '</div>';
            if($theme_sidebar == 'left'):
                echo '<div class="col-lg-4 order-lg-1">
                        <div class="it-blog-sidebar">';
                          get_sidebar();
                 echo  '</div></div>';
            endif; 
            if($theme_sidebar == 'right'):
                echo '<div class="col-lg-4">
                        <div class="it-blog-sidebar">';
                          get_sidebar();
                echo '</div></div>';
            endif;
echo  '</div>
   </div>
</div>';
get_footer();