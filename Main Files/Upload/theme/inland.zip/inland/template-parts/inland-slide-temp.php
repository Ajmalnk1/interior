<?php 
/**
 * Template Name: Slider Page
 */
get_header();
$inland_theme_data ='';
if(function_exists('fw_get_db_settings_option')){
	$inland_theme_data = fw_get_db_settings_option();
}

$page_id = '';
if(!empty($inland_theme_data['home_pages'])){
	$page_id = $inland_theme_data['home_pages'];
}
$args = array(
		'posts_per_page' => -1,
		'post_type' => 'Page',
		'post__in'  => (array) $page_id,
		'orderby' => 'post__in',
 		);
    $home_query = new WP_Query($args);  
	if($home_query->have_posts()):  while($home_query->have_posts()) : $home_query->the_post();
?>
	<div class="swiper-slide it-vertical-slider">
	<div class="swiper_box">
		<?php the_content(); ?>
	</div>					
	</div>	
<?php endwhile;  
endif;
wp_reset_postdata();
 ?>			
</div>
<div class="swiper-pagination"></div>
<?php
get_footer();