<?php 
/**
 * Template Name: Full Width Page
 */
get_header();
$corelibrary = $bgimage = '';
if(class_exists('Inland_corelibrary')):
   $corelibrary = new Inland_corelibrary();
   $bgimage = $corelibrary->inland_theme_background_image();
endif;
$inland_theme_data = '';
if (function_exists('fw_get_db_post_option')):	
    $inland_theme_data = fw_get_db_post_option(get_the_ID());
endif; 
$breadcrumbs_switch = '';
if(!empty($inland_theme_data['page_breadcrumbs_switch'])):
   $breadcrumbs_switch = $inland_theme_data['page_breadcrumbs_switch'];
endif;
if($breadcrumbs_switch == 'on'):
    if(function_exists('inland_breadcrumbs_setting')):
        inland_breadcrumbs_setting(get_the_ID());
    endif;  
endif;
?>
<div class="it-dark-bg" <?php printf($bgimage); ?>>
    <?php
	while ( have_posts() ) : the_post();
		get_template_part( 'template-parts/content', 'full' );
	endwhile; 
	?>
</div>
<?php
get_footer();