<?php
/**
 * Template part for displaying page content
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package inland
 */
?>
<article id="post-<?php the_ID(); ?>">
    <?php 
    the_content();
    wp_link_pages( array(
		'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'inland' ),
		 'after'  => '</div>',
		) );
	
	?>
</article><!-- #post-<?php the_ID(); ?> -->