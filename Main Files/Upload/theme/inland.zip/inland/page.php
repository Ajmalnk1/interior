<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package inland
 */
get_header();
?>
<div id="primary" class="content-area">
	<main id="main" class="site-main">
		<?php
		/**
		 * Inland Page content area
		 */
		$inland_setting = '';
		if(class_exists('Inland_Themesetting')):
			$inland_setting = new Inland_Themesetting();
			if(!function_exists('inland_pages_setting')):
				$inland_setting->inland_pages_setting(get_the_ID());
			endif;
		endif;
		?>
	</main><!-- #main -->
</div><!-- #primary -->
<?php
get_footer();