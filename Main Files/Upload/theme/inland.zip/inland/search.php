<?php
/**
 * The template for displaying search results pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package inland
 */
get_header();
?>
<section id="primary" class="content-area">
	<main id="main" class="site-main"> 
	<?php
		/**
		 * inland Search content area
		 */
		$inland_setting = '';
		if(class_exists('Inland_Themesetting')):
			$inland_setting = new Inland_Themesetting();
			/** * Theme blog */
			if(!function_exists('inland_index_blog')):
				$inland_setting->inland_index_blog(get_the_ID());
			endif;
		endif;
		?>
	</main><!-- #main -->
</section><!-- #primary -->
<?php
get_footer();