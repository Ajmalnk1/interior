<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package inland
 */
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); 
if ( is_page_template( 'template-parts/inland-slide-temp.php' ) ) {
	echo '<div class="it-main-wraapper mouse-wheel-slide">
			<div class="swiper-container it-vertical-slider">
				<div class="swiper-wrapper it-vertical-slider">';
}else{    
	echo '<div class="it-main-wraapper">';
}

/**
 * Inland Header Content Area
 */
$inland_setting = '';
if(class_exists('Inland_Themesetting')):
	$inland_setting = new Inland_Themesetting();
	/**
	 *Theme Header 
  	 */
	if(!function_exists('inland_header_setting')):
		$inland_setting->inland_header_setting();
	endif;
endif;