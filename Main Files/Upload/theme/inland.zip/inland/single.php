<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package inland
 */
get_header();
?>
<div id="primary" class="content-area">
	<main id="main" class="site-main">
	<?php
	/**
	 * Inland blog content area
	 */
	 $inland_setting = '';
	 if(class_exists('Inland_Themesetting')):
		$inland_setting = new Inland_Themesetting();
		if(!function_exists('inland_blog_single_setting')):
			$inland_setting->inland_blog_single_setting(get_the_ID());
		endif;
	endif;
	?>
	</main><!-- #main -->
</div><!-- #primary -->		
<?php
get_footer();