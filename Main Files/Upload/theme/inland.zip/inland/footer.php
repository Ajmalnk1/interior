<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package inland
 */
 
/**
 * inland blog content area
 */
$inland_setting = '';
if(class_exists('Inland_Themesetting')):
   $inland_setting = new Inland_Themesetting();
   /** * Footer section */
   if(!function_exists('inland_footer_setting')):
      $inland_setting->inland_footer_setting();
   endif;
endif;
$themeoption_data = '';
if (function_exists('fw_get_db_settings_option')):
    $themeoption_data = fw_get_db_settings_option();
endif;
$copyright_text = '';
if(!empty($themeoption_data['copyright_text'])):
	$copyright_text = $themeoption_data['copyright_text'];
endif;
?>
<div class="it-bottom-footer-wrapper"> 
    <div class="container">
        <div class="bottom-footer-box-wrapper text-center">
            <div class="row">
                <div class="col-md-12">
                    <?php if(!empty($copyright_text)): ?>
                    <p><?php echo wp_kses($copyright_text, true); ?></p>
                    <?php else: ?>
                    <p><?php esc_html_e('&copy; Copyright 2020, All Rights Reserved','inland'); ?>
                	      <a href="<?php echo esc_url('https://kamleshyadav.com/wp/inland'); ?>">
                        <?php esc_html_e('Inland','inland'); ?></a>
                    </p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php 
if ( is_page_template( 'inland-slide-temp.php' ) ) {
	echo '</div></div></div>';
}
else{
	echo '</div>';
}	
wp_footer(); ?>
</body>
</html>  